var structaiopti__sgd =
[
    [ "base", "structaiopti__sgd.html#a76e9fa4cf381a685a5df819a57737e64", null ],
    [ "momentum", "structaiopti__sgd.html#a4be2a7d03bb9aeca3a064739b167098a", null ],
    [ "scalar_mul", "structaiopti__sgd.html#a2cbbfaac40611a8dd0ec908cc199b388", null ],
    [ "tensor_add", "structaiopti__sgd.html#a7674445f16490c6cacdb03157feab8c7", null ],
    [ "tensor_sub", "structaiopti__sgd.html#a5f5b55cad6c306233a8e4510d1773244", null ],
    [ "zero_tensor", "structaiopti__sgd.html#aa0c5520df9a1bfa236b1ef7eddeb3553", null ]
];