var aiopti__adam__default_8h =
[
    [ "aiopti_adam_f32", "structaiopti__adam__f32.html", "structaiopti__adam__f32" ],
    [ "aiopti_adam_f32_t", "aiopti__adam__default_8h.html#a13e16523a35fb20fc719337b5104e0b1", null ],
    [ "aiopti_adam_f32_default", "aiopti__adam__default_8h.html#a403603bdc0d77e2d1cbc3fd4cd37880a", null ],
    [ "aiopti_adam_f32_default_begin_step", "aiopti__adam__default_8h.html#a0f5a44e9e363b8b8bbb1d3ad6b8e7658", null ],
    [ "aiopti_adam_f32_default_end_step", "aiopti__adam__default_8h.html#a162ef93a1e3dc3c7fc3267dd6862c21b", null ]
];