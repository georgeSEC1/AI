var structaiopti__adam__momentums =
[
    [ "m", "structaiopti__adam__momentums.html#ac8a952596756d8af1ce2a52ee44b6d2b", null ],
    [ "v", "structaiopti__adam__momentums.html#a018a8a9b15ab10dd50e0ded5cd5bfdda", null ]
];