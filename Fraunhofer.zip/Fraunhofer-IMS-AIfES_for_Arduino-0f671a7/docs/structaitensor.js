var structaitensor =
[
    [ "data", "structaitensor.html#a735984d41155bc1032e09bece8f8d66d", null ],
    [ "dim", "structaitensor.html#acd6b0c9d182822b4646f744da608eb78", null ],
    [ "dtype", "structaitensor.html#abf7a461af7296a09d5246ca13591b988", null ],
    [ "shape", "structaitensor.html#a2c6232867935ce2511be6f94dd8bab6b", null ],
    [ "tensor_params", "structaitensor.html#ab615dd1ddcc27064097dd98cbc7fe9a0", null ]
];