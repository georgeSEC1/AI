var structailayer__softsign =
[
    [ "base", "structailayer__softsign.html#ab13782a46e3804246bf82a92955096b3", null ],
    [ "d_softsign", "structailayer__softsign.html#a624ba640f91dcccd86c66c29d864a74e", null ],
    [ "dtype", "structailayer__softsign.html#abf7a461af7296a09d5246ca13591b988", null ],
    [ "multiply", "structailayer__softsign.html#a50f5e44b0fca9c1e79a5287adb4a59eb", null ],
    [ "softsign", "structailayer__softsign.html#a69015bf44765cb038dd6ba7ffc910dfb", null ]
];