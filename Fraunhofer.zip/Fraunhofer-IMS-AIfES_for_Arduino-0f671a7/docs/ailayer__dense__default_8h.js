var ailayer__dense__default_8h =
[
    [ "ailayer_dense_f32_t", "ailayer__dense__default_8h.html#a58a8842e71f549f60fa921de7736507c", null ],
    [ "ailayer_dense_q31_t", "ailayer__dense__default_8h.html#a604095553ddfa1af6c00623845e50e6e", null ],
    [ "ailayer_dense_q7_t", "ailayer__dense__default_8h.html#ab91b3a9cd085fb39253c5605edebc58e", null ],
    [ "ailayer_dense_f32_default", "ailayer__dense__default_8h.html#a5f58ad071502178879dccb0acab8b74b", null ],
    [ "ailayer_dense_q31_default", "ailayer__dense__default_8h.html#a65a027083aa5dc87b78d52f00fd48e76", null ],
    [ "ailayer_dense_q7_default", "ailayer__dense__default_8h.html#a039ecc8141aac279c2d09d79443a2717", null ],
    [ "ailayer_dense_quantize_q7_from_f32", "ailayer__dense__default_8h.html#a61548ce1f4b5aff6964fa558e2955d2a", null ],
    [ "ailayer_dense_wt_q7_default", "ailayer__dense__default_8h.html#acd55d4485ba046577ccbb0a2f314ae34", null ]
];