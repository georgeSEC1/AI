var structaicore__optitype =
[
    [ "name", "structaicore__optitype.html#a8f8f80d37794cde9472343e4487ba3eb", null ],
    [ "print_specs", "structaicore__optitype.html#a6c47b929d158f7ef286d7faef130e018", null ]
];