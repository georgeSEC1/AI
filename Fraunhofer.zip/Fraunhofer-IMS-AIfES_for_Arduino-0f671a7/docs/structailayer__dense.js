var structailayer__dense =
[
    [ "base", "structailayer__dense.html#ab13782a46e3804246bf82a92955096b3", null ],
    [ "bias", "structailayer__dense.html#a87664225b3b1ad7ec4cb74cc8bd8f349", null ],
    [ "bias_dtype", "structailayer__dense.html#a17a8ca066103eec65631c29fa6b02835", null ],
    [ "bias_shape", "structailayer__dense.html#ab7bfe5488f8564289357bfc1b2217af8", null ],
    [ "gradients", "structailayer__dense.html#a33b189c78566d57ad498dbf2cc364917", null ],
    [ "linear", "structailayer__dense.html#a7218a352357b1fb602775252d8286ce6", null ],
    [ "mat_mul", "structailayer__dense.html#ae42c3139db5213ba8619454dc7e026f7", null ],
    [ "neurons", "structailayer__dense.html#aa7ae0d08cc0a75b22e656b9e2e3c336b", null ],
    [ "optimem", "structailayer__dense.html#a590c48e998a8a740439e38d0aa4302dd", null ],
    [ "result_dtype", "structailayer__dense.html#a5b5e058a3c6e700e479d7ebe26be8b9e", null ],
    [ "result_shape", "structailayer__dense.html#ab733a6d9451ea97c43c593a495f26d51", null ],
    [ "tensor_add", "structailayer__dense.html#a7674445f16490c6cacdb03157feab8c7", null ],
    [ "trainable_params", "structailayer__dense.html#afcc6c64ff572ae7408fe1c4bcfe7b9d1", null ],
    [ "weights", "structailayer__dense.html#abaaf545fb7c9d3a0b80aa5a460202e04", null ],
    [ "weights_dtype", "structailayer__dense.html#ac60e4cfc06883718a1593259fdf8b5c9", null ],
    [ "weights_shape", "structailayer__dense.html#a055e3841d49ce4e2d8c52f4bf4536641", null ]
];