var struct_a_i_f_e_s___e__model__parameter__fnn__f32 =
[
    [ "flat_weights", "struct_a_i_f_e_s___e__model__parameter__fnn__f32.html#a4c8ac1a2e6acb80433ed33dafe5e703d", null ],
    [ "fnn_activations", "struct_a_i_f_e_s___e__model__parameter__fnn__f32.html#ac19fe5a39b6c6c68774d040417741b5c", null ],
    [ "fnn_structure", "struct_a_i_f_e_s___e__model__parameter__fnn__f32.html#ac0e27d2721e3fc56a5271daa70a1c4cf", null ],
    [ "layer_count", "struct_a_i_f_e_s___e__model__parameter__fnn__f32.html#a7c6673fb07eaacde14fefa8739cf81d9", null ]
];