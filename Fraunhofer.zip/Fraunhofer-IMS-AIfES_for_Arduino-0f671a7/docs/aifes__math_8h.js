var aifes__math_8h =
[
    [ "aimath_dtype", "structaimath__dtype.html", "structaimath__dtype" ],
    [ "aitensor", "structaitensor.html", "structaitensor" ],
    [ "aimath_dtype_t", "aifes__math_8h.html#ac57f449148b5466bdb47862a44bbec00", null ],
    [ "aitensor_t", "aifes__math_8h.html#af7b6e9b34a5f33385536f40624fda8ca", null ]
];