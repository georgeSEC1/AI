var ailayer__softsign__default_8h =
[
    [ "ailayer_softsign_f32_t", "ailayer__softsign__default_8h.html#ab7c0232cce2a1f9abe50e3e80e9a3139", null ],
    [ "ailayer_softsign_q31_t", "ailayer__softsign__default_8h.html#a023ec7c7b08c5c0d44b1efa3222be817", null ],
    [ "ailayer_softsign_q7_t", "ailayer__softsign__default_8h.html#a56f4babd3b376a0bf7f7b2c1b727f082", null ],
    [ "ailayer_softsign_calc_result_tensor_params_q31_default", "ailayer__softsign__default_8h.html#a2eda8794f3d7717d68fe55f91454d9bf", null ],
    [ "ailayer_softsign_calc_result_tensor_params_q7_default", "ailayer__softsign__default_8h.html#a14fa2d706dd14106cf49c72e0e9f94f2", null ],
    [ "ailayer_softsign_f32_default", "ailayer__softsign__default_8h.html#a61bd457b1738a257f9adfd4130246c16", null ],
    [ "ailayer_softsign_q31_default", "ailayer__softsign__default_8h.html#ad73c4997f1ece486930de9f1f5066b34", null ],
    [ "ailayer_softsign_q7_default", "ailayer__softsign__default_8h.html#adc181fff8c1a26defd81592b9818edc7", null ]
];