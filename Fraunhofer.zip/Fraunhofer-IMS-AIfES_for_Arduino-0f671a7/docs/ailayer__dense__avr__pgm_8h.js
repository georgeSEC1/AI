var ailayer__dense__avr__pgm_8h =
[
    [ "ailayer_dense_f32_avr_pgm", "ailayer__dense__avr__pgm_8h.html#a1b989bfc9a5480568ec1800c995eb063", null ],
    [ "ailayer_dense_q7_avr_pgm", "ailayer__dense__avr__pgm_8h.html#a8b92ee421b5dc51909e96a7a0bae93b8", null ],
    [ "ailayer_dense_wt_q7_avr_pgm", "ailayer__dense__avr__pgm_8h.html#ae99d06b3b85bbb94a6dd58c4e3760a02", null ]
];