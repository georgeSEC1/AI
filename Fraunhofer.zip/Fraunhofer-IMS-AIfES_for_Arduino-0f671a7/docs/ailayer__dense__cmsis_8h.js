var ailayer__dense__cmsis_8h =
[
    [ "ailayer_dense_f32_cmsis", "ailayer__dense__cmsis_8h.html#ae4d838f2bde7df2c469aac4ac6a15a46", null ],
    [ "ailayer_dense_wt_q7_cmsis", "ailayer__dense__cmsis_8h.html#a4ced6d503f0f851d90050b344f47c638", null ]
];