var ailayer__softsign_8h =
[
    [ "ailayer_softsign", "structailayer__softsign.html", "structailayer__softsign" ],
    [ "ailayer_softsign_t", "ailayer__softsign_8h.html#afbce5475fd8c19b93c5c26fbc71655d0", null ],
    [ "ailayer_softsign", "ailayer__softsign_8h.html#a26db246ab9aae6a15963e7eeba7d8598", null ],
    [ "ailayer_softsign_backward", "ailayer__softsign_8h.html#a996347cf358384cbbe1dc311eed5f084", null ],
    [ "ailayer_softsign_calc_result_shape", "ailayer__softsign_8h.html#ab2ec8fc75420eb692709b864650f1d42", null ],
    [ "ailayer_softsign_forward", "ailayer__softsign_8h.html#aacf2b1e644b07eca0a0a58cece19d717", null ],
    [ "ailayer_softsign_print_specs", "ailayer__softsign_8h.html#ae8271bea0ebd04711d269fa017b0b308", null ],
    [ "ailayer_softsign_type", "ailayer__softsign_8h.html#a9ed464f1284b6b6af9903e79d157b2fe", null ]
];