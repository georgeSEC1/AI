var ailayer__tanh__avr__pgm_8h =
[
    [ "ailayer_tanh_q7_avr_pgm", "ailayer__tanh__avr__pgm_8h.html#aec0b62504938d3fa5bc936a02d8bf0bc", null ]
];