var structailayer__elu__q7 =
[
    [ "alpha", "structailayer__elu__q7.html#a539517a0a6e01c1f0a5e15426efe6a49", null ],
    [ "base", "structailayer__elu__q7.html#a6d80585658fb6a5a14c46fefd49ac0ba", null ]
];