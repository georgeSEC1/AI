var structaicore__losstype =
[
    [ "name", "structaicore__losstype.html#a8f8f80d37794cde9472343e4487ba3eb", null ],
    [ "print_specs", "structaicore__losstype.html#a7ea4e2b11ece1dd4870f0fb364c15253", null ]
];