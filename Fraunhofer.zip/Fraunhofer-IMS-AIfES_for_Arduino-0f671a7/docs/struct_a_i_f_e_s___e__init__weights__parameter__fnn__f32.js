var struct_a_i_f_e_s___e__init__weights__parameter__fnn__f32 =
[
    [ "init_weights_method", "struct_a_i_f_e_s___e__init__weights__parameter__fnn__f32.html#a53ff47a067c37773857386dea83f220b", null ],
    [ "max_init_uniform", "struct_a_i_f_e_s___e__init__weights__parameter__fnn__f32.html#a09a78ab3d9ca0ad35d0a2d723982c224", null ],
    [ "min_init_uniform", "struct_a_i_f_e_s___e__init__weights__parameter__fnn__f32.html#a732cb7bae8da3d3e600e5b8a8e4e725d", null ]
];