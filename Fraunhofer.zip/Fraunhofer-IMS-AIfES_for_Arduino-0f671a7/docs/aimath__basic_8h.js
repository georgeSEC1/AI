var aimath__basic_8h =
[
    [ "aimath_sizeof_dtype", "aimath__basic_8h.html#adb2e8e78c254bba409ca94b989fb0aed", null ],
    [ "aimath_sizeof_tensor", "aimath__basic_8h.html#a47674c7536683118f1fa711c3c5c883e", null ],
    [ "aimath_sizeof_tensor_data", "aimath__basic_8h.html#aed334e3dae9f383fde9c43e99872c745", null ],
    [ "aimath_sizeof_tensor_params", "aimath__basic_8h.html#afe922f577551340a7d559c3a722baa69", null ],
    [ "aimath_tensor_elements", "aimath__basic_8h.html#af298fd08e5d0e8182aac03c34dcbfbc0", null ],
    [ "aimath_transpose_vector", "aimath__basic_8h.html#a2493f76ff7bca07ccfce567c2e678ece", null ],
    [ "print_aiscalar", "aimath__basic_8h.html#aaa9ca757028820849ef3dde13cc46565", null ],
    [ "print_aitensor", "aimath__basic_8h.html#ab10c8d06990943806f0be8fcc6af03fc", null ]
];