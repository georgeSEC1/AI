var aimath__q7__avr__pgm_8h =
[
    [ "aimath_q7_avr_pgm_elu", "aimath__q7__avr__pgm_8h.html#a491ba7e29be29a27051c9a483afb983c", null ],
    [ "aimath_q7_avr_pgm_leaky_relu", "aimath__q7__avr__pgm_8h.html#ad4d2f63c565e7d4b9ac2cf7aef6c4844", null ],
    [ "aimath_q7_avr_pgm_linear32_1", "aimath__q7__avr__pgm_8h.html#a565effb18ceb9ce927a2e9bfd01174e9", null ],
    [ "aimath_q7_avr_pgm_linear32_2", "aimath__q7__avr__pgm_8h.html#a2897c9e4917a426b7a83a5fa95256add", null ],
    [ "aimath_q7_avr_pgm_linear32_bt_1", "aimath__q7__avr__pgm_8h.html#a7f2891f81c38a6c75ee83e30da2937b9", null ],
    [ "aimath_q7_avr_pgm_linear32_bt_2", "aimath__q7__avr__pgm_8h.html#a555535953ea7986db3dcf491944b03f2", null ],
    [ "aimath_q7_avr_pgm_relu", "aimath__q7__avr__pgm_8h.html#a53d817c9981488e8d0dacb91320cda9f", null ],
    [ "aimath_q7_avr_pgm_sigmoid", "aimath__q7__avr__pgm_8h.html#ad79eb5d753d38e97347096fd64783a46", null ],
    [ "aimath_q7_avr_pgm_softmax", "aimath__q7__avr__pgm_8h.html#aab25d76339b480c860dbc909cfd4049c", null ],
    [ "aimath_q7_avr_pgm_softsign", "aimath__q7__avr__pgm_8h.html#a7a63ddf00a06d19456f79a1cf49b0ef2", null ],
    [ "aimath_q7_avr_pgm_tanh", "aimath__q7__avr__pgm_8h.html#a0d03214721c6da17a577865834634de7", null ]
];