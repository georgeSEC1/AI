var structaimath__dtype =
[
    [ "name", "structaimath__dtype.html#a8f8f80d37794cde9472343e4487ba3eb", null ],
    [ "print_aiscalar", "structaimath__dtype.html#a08e786bc3ccde258981cff5b20988a51", null ],
    [ "print_aitensor", "structaimath__dtype.html#a31255ef6a6f99a7fbe3685dec7f29218", null ],
    [ "size", "structaimath__dtype.html#ab2c6b258f02add8fdf4cfc7c371dd772", null ],
    [ "tensor_params_size", "structaimath__dtype.html#a05bb6981d499d285a533edfc40bab941", null ]
];