var searchData=
[
  ['calc_5fdelta_442',['calc_delta',['../structailoss.html#ae84860a963e24221ba373a1554f20930',1,'ailoss']]],
  ['calc_5floss_443',['calc_loss',['../structailoss.html#afb6e75cd4aa201c51f7f220dc15abcb3',1,'ailoss']]],
  ['calc_5fresult_5fshape_444',['calc_result_shape',['../structailayer.html#a66787e37cfd371070476221e86386f7c',1,'ailayer']]],
  ['calc_5fresult_5ftensor_5fparams_445',['calc_result_tensor_params',['../structailayer.html#ab5e8fd65efe85a1ee1ac9147594ddd61',1,'ailayer']]],
  ['connection_5flayer_446',['connection_layer',['../structailoss.html#ad7053c8e36973515431688c9efe026ce',1,'ailoss']]],
  ['copy_5ftensor_447',['copy_tensor',['../structailayer__template.html#a83c24bfde9518ea3fca2ed9ab785d59a',1,'ailayer_template']]],
  ['crossentropy_448',['crossentropy',['../structailoss__crossentropy.html#aedaeff294e1c5d7e56da1531faa50fe4',1,'ailoss_crossentropy']]]
];
