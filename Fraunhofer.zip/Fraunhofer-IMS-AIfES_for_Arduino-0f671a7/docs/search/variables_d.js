var searchData=
[
  ['relu_1042',['relu',['../structailayer__relu.html#aa86168e5f130c59eacbedb95be431aab',1,'ailayer_relu']]],
  ['result_1043',['result',['../structailayer.html#a1ed86d1fec7aae68bc79c55f3f965790',1,'ailayer']]],
  ['result_5fdtype_1044',['result_dtype',['../structailayer__dense.html#a5b5e058a3c6e700e479d7ebe26be8b9e',1,'ailayer_dense']]],
  ['result_5fshape_1045',['result_shape',['../structailayer__dense.html#ab733a6d9451ea97c43c593a495f26d51',1,'ailayer_dense::result_shape()'],['../structailayer__template.html#ab733a6d9451ea97c43c593a495f26d51',1,'ailayer_template::result_shape()']]]
];
