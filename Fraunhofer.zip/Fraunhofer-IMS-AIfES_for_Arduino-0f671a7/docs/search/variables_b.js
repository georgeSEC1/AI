var searchData=
[
  ['one_5fminus_5fbeta1_1032',['one_minus_beta1',['../structaiopti__adam.html#a508e23c3b1a359c4dc09fd4aca55b5be',1,'aiopti_adam::one_minus_beta1()'],['../structaiopti__adam__f32.html#a02e260a8f1cec862011a285d8af0f9f7',1,'aiopti_adam_f32::one_minus_beta1()']]],
  ['one_5fminus_5fbeta2_1033',['one_minus_beta2',['../structaiopti__adam.html#a6a78981ba0fc6b6c94018fbbf550eeae',1,'aiopti_adam::one_minus_beta2()'],['../structaiopti__adam__f32.html#a6cf0c7e58cbeaa620a0323eca2176871',1,'aiopti_adam_f32::one_minus_beta2()']]],
  ['optimem_1034',['optimem',['../structailayer__dense.html#a590c48e998a8a740439e38d0aa4302dd',1,'ailayer_dense::optimem()'],['../structailayer__template.html#a590c48e998a8a740439e38d0aa4302dd',1,'ailayer_template::optimem()'],['../structailayer.html#a0d7d5229bb3c514d7bd3e2bcf40c5f5a',1,'ailayer::optimem()']]],
  ['optimizer_1035',['optimizer',['../struct_a_i_f_e_s___e__training__parameter__fnn__f32.html#a9f597ad8d0c7bedb69b05275c9c5acc3',1,'AIFES_E_training_parameter_fnn_f32']]],
  ['optimizer_5fconfiguration_1036',['optimizer_configuration',['../structaiopti.html#a137684e527116392d2672299bc93b95c',1,'aiopti']]],
  ['optimizer_5ftype_1037',['optimizer_type',['../structaiopti.html#a6ca0fdd2169bc462e1cc4f87e786933d',1,'aiopti']]],
  ['output_5flayer_1038',['output_layer',['../structaimodel.html#a7c7ad89e7d15631b3f5893b8f19030ef',1,'aimodel']]]
];
