var searchData=
[
  ['m_489',['m',['../structaiopti__adam__momentums.html#ac8a952596756d8af1ce2a52ee44b6d2b',1,'aiopti_adam_momentums']]],
  ['main_20page_490',['Main page',['../index.html',1,'']]],
  ['mat_5fmul_491',['mat_mul',['../structailayer__dense.html#ae42c3139db5213ba8619454dc7e026f7',1,'ailayer_dense']]],
  ['max_5finit_5funiform_492',['max_init_uniform',['../struct_a_i_f_e_s___e__init__weights__parameter__fnn__f32.html#a09a78ab3d9ca0ad35d0a2d723982c224',1,'AIFES_E_init_weights_parameter_fnn_f32']]],
  ['min_5finit_5funiform_493',['min_init_uniform',['../struct_a_i_f_e_s___e__init__weights__parameter__fnn__f32.html#a732cb7bae8da3d3e600e5b8a8e4e725d',1,'AIFES_E_init_weights_parameter_fnn_f32']]],
  ['momentum_494',['momentum',['../structaiopti__sgd.html#a4be2a7d03bb9aeca3a064739b167098a',1,'aiopti_sgd::momentum()'],['../structaiopti__sgd__f32.html#ac5a20618f5afb39efca892de7a2b68c6',1,'aiopti_sgd_f32::momentum()'],['../structaiopti__sgd__q31.html#a2f7d2e5e4cde9ec10f5bc5945ca157bf',1,'aiopti_sgd_q31::momentum()']]],
  ['multiply_495',['multiply',['../structailayer__elu.html#a50f5e44b0fca9c1e79a5287adb4a59eb',1,'ailayer_elu::multiply()'],['../structailayer__leaky__relu.html#a50f5e44b0fca9c1e79a5287adb4a59eb',1,'ailayer_leaky_relu::multiply()'],['../structailayer__relu.html#a50f5e44b0fca9c1e79a5287adb4a59eb',1,'ailayer_relu::multiply()'],['../structailayer__sigmoid.html#a50f5e44b0fca9c1e79a5287adb4a59eb',1,'ailayer_sigmoid::multiply()'],['../structailayer__softsign.html#a50f5e44b0fca9c1e79a5287adb4a59eb',1,'ailayer_softsign::multiply()'],['../structailayer__tanh.html#a50f5e44b0fca9c1e79a5287adb4a59eb',1,'ailayer_tanh::multiply()'],['../structaiopti__adam.html#a50f5e44b0fca9c1e79a5287adb4a59eb',1,'aiopti_adam::multiply()']]]
];
