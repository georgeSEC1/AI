var searchData=
[
  ['d_5felu_983',['d_elu',['../structailayer__elu.html#a2817605e9ff5b047ff6192a2c8fae65d',1,'ailayer_elu']]],
  ['d_5fleaky_5frelu_984',['d_leaky_relu',['../structailayer__leaky__relu.html#aec0246cd034131a14c8f77d21dd65dda',1,'ailayer_leaky_relu']]],
  ['d_5frelu_985',['d_relu',['../structailayer__relu.html#a9ecbdfe6b09d45308df2145094445ab9',1,'ailayer_relu']]],
  ['d_5fsigmoid_986',['d_sigmoid',['../structailayer__sigmoid.html#a881096205316190ae52edbc7c4997e4d',1,'ailayer_sigmoid']]],
  ['d_5fsoftsign_987',['d_softsign',['../structailayer__softsign.html#a624ba640f91dcccd86c66c29d864a74e',1,'ailayer_softsign']]],
  ['d_5ftanh_988',['d_tanh',['../structailayer__tanh.html#a42dec6b025b13da223c8a8697f1c5d31',1,'ailayer_tanh']]],
  ['data_989',['data',['../structaitensor.html#a735984d41155bc1032e09bece8f8d66d',1,'aitensor']]],
  ['deltas_990',['deltas',['../structailayer.html#a6e0cd193754d9614d5da823f0f0fcbf6',1,'ailayer']]],
  ['dim_991',['dim',['../structaitensor.html#acd6b0c9d182822b4646f744da608eb78',1,'aitensor']]],
  ['divide_992',['divide',['../structaiopti__adam.html#a5c1478e75fa8c703a1ed25b1091a6bc4',1,'aiopti_adam']]],
  ['dtype_993',['dtype',['../structaitensor.html#abf7a461af7296a09d5246ca13591b988',1,'aitensor::dtype()'],['../structaiopti.html#abf7a461af7296a09d5246ca13591b988',1,'aiopti::dtype()'],['../structailoss__mse.html#abf7a461af7296a09d5246ca13591b988',1,'ailoss_mse::dtype()'],['../structailoss__crossentropy.html#abf7a461af7296a09d5246ca13591b988',1,'ailoss_crossentropy::dtype()'],['../structailayer__template.html#abf7a461af7296a09d5246ca13591b988',1,'ailayer_template::dtype()'],['../structailayer__tanh.html#abf7a461af7296a09d5246ca13591b988',1,'ailayer_tanh::dtype()'],['../structailayer__softsign.html#abf7a461af7296a09d5246ca13591b988',1,'ailayer_softsign::dtype()'],['../structailayer__softmax.html#abf7a461af7296a09d5246ca13591b988',1,'ailayer_softmax::dtype()'],['../structailayer__sigmoid.html#abf7a461af7296a09d5246ca13591b988',1,'ailayer_sigmoid::dtype()'],['../structailayer__relu.html#abf7a461af7296a09d5246ca13591b988',1,'ailayer_relu::dtype()'],['../structailayer__leaky__relu.html#abf7a461af7296a09d5246ca13591b988',1,'ailayer_leaky_relu::dtype()'],['../structailayer__input.html#abf7a461af7296a09d5246ca13591b988',1,'ailayer_input::dtype()'],['../structailayer__elu.html#abf7a461af7296a09d5246ca13591b988',1,'ailayer_elu::dtype()']]]
];
