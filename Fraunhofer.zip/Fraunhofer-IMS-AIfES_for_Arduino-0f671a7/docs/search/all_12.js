var searchData=
[
  ['weights_541',['weights',['../structailayer__dense.html#abaaf545fb7c9d3a0b80aa5a460202e04',1,'ailayer_dense']]],
  ['weights_5fdtype_542',['weights_dtype',['../structailayer__dense.html#ac60e4cfc06883718a1593259fdf8b5c9',1,'ailayer_dense']]],
  ['weights_5fshape_543',['weights_shape',['../structailayer__dense.html#a055e3841d49ce4e2d8c52f4bf4536641',1,'ailayer_dense']]]
];
