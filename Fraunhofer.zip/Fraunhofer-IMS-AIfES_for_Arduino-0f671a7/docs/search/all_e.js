var searchData=
[
  ['scalar_5fadd_513',['scalar_add',['../structaiopti__adam.html#a5aaf0a1aa2e5c1674e5b4be2f80f907f',1,'aiopti_adam']]],
  ['scalar_5fmul_514',['scalar_mul',['../structaiopti__adam.html#a2cbbfaac40611a8dd0ec908cc199b388',1,'aiopti_adam::scalar_mul()'],['../structaiopti__sgd.html#a2cbbfaac40611a8dd0ec908cc199b388',1,'aiopti_sgd::scalar_mul()']]],
  ['set_5fparamem_515',['set_paramem',['../structailayer.html#a219921bd3b75e98894a33f6c2ff61c07',1,'ailayer']]],
  ['set_5ftrainmem_516',['set_trainmem',['../structailayer.html#a5062b6bf991a3ae278941c560847eeb6',1,'ailayer']]],
  ['sgd_5fmomentum_517',['sgd_momentum',['../struct_a_i_f_e_s___e__training__parameter__fnn__f32.html#a349b9731a66bc2f669c93112b5fc50ff',1,'AIFES_E_training_parameter_fnn_f32']]],
  ['shape_518',['shape',['../structaitensor.html#a2c6232867935ce2511be6f94dd8bab6b',1,'aitensor']]],
  ['shift_519',['shift',['../structaimath__q7__params.html#a8f20d77488fe485aaf9ea8e9c5d7d35e',1,'aimath_q7_params::shift()'],['../structaiscalar__q7.html#a8f20d77488fe485aaf9ea8e9c5d7d35e',1,'aiscalar_q7::shift()'],['../structaiscalar__q31.html#a8f20d77488fe485aaf9ea8e9c5d7d35e',1,'aiscalar_q31::shift()'],['../structaimath__q31__params.html#a8f20d77488fe485aaf9ea8e9c5d7d35e',1,'aimath_q31_params::shift()']]],
  ['sigmoid_520',['sigmoid',['../structailayer__sigmoid.html#a427b044bddf241f9ffdf0258c7304c3c',1,'ailayer_sigmoid']]],
  ['size_521',['size',['../structaimath__dtype.html#ab2c6b258f02add8fdf4cfc7c371dd772',1,'aimath_dtype']]],
  ['sizeof_5foptimem_522',['sizeof_optimem',['../structaiopti.html#a948b4e86692cb9306c71c1099a6ba67d',1,'aiopti']]],
  ['sizeof_5fparamem_523',['sizeof_paramem',['../structailayer.html#ab758b2be3966c7cc0bf6920a60886bbf',1,'ailayer']]],
  ['sizeof_5ftrainmem_524',['sizeof_trainmem',['../structailayer.html#af95ecd0e925bff73b30b1d1b6fc21028',1,'ailayer']]],
  ['softmax_525',['softmax',['../structailayer__softmax.html#a25a735df26bb4003f7b15dfe4c95476f',1,'ailayer_softmax']]],
  ['softsign_526',['softsign',['../structailayer__softsign.html#a69015bf44765cb038dd6ba7ffc910dfb',1,'ailayer_softsign']]],
  ['sqrt_527',['sqrt',['../structaiopti__adam.html#a5d36deab4e71dd3b8d45ea2fff8f4b55',1,'aiopti_adam']]]
];
