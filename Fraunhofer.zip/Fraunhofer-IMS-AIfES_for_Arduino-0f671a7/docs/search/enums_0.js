var searchData=
[
  ['aifes_5fe_5factivations_1086',['AIFES_E_activations',['../aifes__express__f32__fnn_8h.html#a6dad88532ecc9bc7786bb69c0aab7c23',1,'aifes_express_f32_fnn.h']]],
  ['aifes_5fe_5fearly_5fstopping_1087',['AIFES_E_early_stopping',['../aifes__express__f32__fnn_8h.html#a4e0a3b4a420060fb232004d3bce5f878',1,'aifes_express_f32_fnn.h']]],
  ['aifes_5fe_5finit_5fweights_5fmethod_1088',['AIFES_E_init_weights_method',['../aifes__express__f32__fnn_8h.html#a35acc0093cf3f0ad28eb5c49b23d5e44',1,'aifes_express_f32_fnn.h']]],
  ['aifes_5fe_5floss_1089',['AIFES_E_loss',['../aifes__express__f32__fnn_8h.html#a9d5599ca9f2382ad1150d53f6ba8cbea',1,'aifes_express_f32_fnn.h']]],
  ['aifes_5fe_5foptimizer_1090',['AIFES_E_optimizer',['../aifes__express__f32__fnn_8h.html#ac3fa2f42fb47ee5af7c7a3282d4f4cd0',1,'aifes_express_f32_fnn.h']]]
];
