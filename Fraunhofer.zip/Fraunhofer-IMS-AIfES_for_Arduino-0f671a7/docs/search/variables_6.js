var searchData=
[
  ['gradients_1005',['gradients',['../structailayer__dense.html#a33b189c78566d57ad498dbf2cc364917',1,'ailayer_dense::gradients()'],['../structailayer__template.html#a33b189c78566d57ad498dbf2cc364917',1,'ailayer_template::gradients()'],['../structailayer.html#adf565818ce1d94c39e818326a25a6de8',1,'ailayer::gradients()']]]
];
