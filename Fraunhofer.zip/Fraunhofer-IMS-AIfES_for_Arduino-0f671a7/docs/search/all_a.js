var searchData=
[
  ['name_496',['name',['../structaicore__layertype.html#a8f8f80d37794cde9472343e4487ba3eb',1,'aicore_layertype::name()'],['../structaicore__losstype.html#a8f8f80d37794cde9472343e4487ba3eb',1,'aicore_losstype::name()'],['../structaicore__optitype.html#a8f8f80d37794cde9472343e4487ba3eb',1,'aicore_optitype::name()'],['../structaimath__dtype.html#a8f8f80d37794cde9472343e4487ba3eb',1,'aimath_dtype::name()']]],
  ['neurons_497',['neurons',['../structailayer__dense.html#aa7ae0d08cc0a75b22e656b9e2e3c336b',1,'ailayer_dense']]],
  ['norm_5fsquared_498',['norm_squared',['../structailoss__mse.html#afa10b339e3aeb58766e81c49a18bbea2',1,'ailoss_mse']]]
];
