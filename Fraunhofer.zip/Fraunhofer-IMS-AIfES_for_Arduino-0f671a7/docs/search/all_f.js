var searchData=
[
  ['tanh_528',['tanh',['../structailayer__tanh.html#a044094cf164cf12ae0a5cc682dfc9804',1,'ailayer_tanh']]],
  ['tensor_5fadd_529',['tensor_add',['../structailayer__dense.html#a7674445f16490c6cacdb03157feab8c7',1,'ailayer_dense::tensor_add()'],['../structailayer__template.html#a7674445f16490c6cacdb03157feab8c7',1,'ailayer_template::tensor_add()'],['../structaiopti__adam.html#a7674445f16490c6cacdb03157feab8c7',1,'aiopti_adam::tensor_add()'],['../structaiopti__sgd.html#a7674445f16490c6cacdb03157feab8c7',1,'aiopti_sgd::tensor_add()']]],
  ['tensor_5fparams_530',['tensor_params',['../structaitensor.html#ab615dd1ddcc27064097dd98cbc7fe9a0',1,'aitensor']]],
  ['tensor_5fparams_5fsize_531',['tensor_params_size',['../structaimath__dtype.html#a05bb6981d499d285a533edfc40bab941',1,'aimath_dtype']]],
  ['tensor_5fsub_532',['tensor_sub',['../structaiopti__adam.html#a5f5b55cad6c306233a8e4510d1773244',1,'aiopti_adam::tensor_sub()'],['../structaiopti__sgd.html#a5f5b55cad6c306233a8e4510d1773244',1,'aiopti_sgd::tensor_sub()'],['../structailoss__mse.html#a5f5b55cad6c306233a8e4510d1773244',1,'ailoss_mse::tensor_sub()'],['../structailoss__crossentropy.html#a5f5b55cad6c306233a8e4510d1773244',1,'ailoss_crossentropy::tensor_sub()']]],
  ['trainable_5fparams_533',['trainable_params',['../structailayer__dense.html#afcc6c64ff572ae7408fe1c4bcfe7b9d1',1,'ailayer_dense::trainable_params()'],['../structailayer__template.html#afcc6c64ff572ae7408fe1c4bcfe7b9d1',1,'ailayer_template::trainable_params()'],['../structailayer.html#a8a3410d74de23e53ffb75649fec0851a',1,'ailayer::trainable_params()']]],
  ['trainable_5fparams_5fcount_534',['trainable_params_count',['../structaimodel.html#a0ccfc06a73c9325540dea85791a1e36b',1,'aimodel::trainable_params_count()'],['../structailayer.html#a328cb32bcb611f02ace7da86ab9711a2',1,'ailayer::trainable_params_count()']]],
  ['tutorial_20inference_20f32_535',['Tutorial inference F32',['../_tutorial_inference_f32.html',1,'']]],
  ['tutorial_20inference_20q7_536',['Tutorial inference Q7',['../_tutorial_inference_q7.html',1,'']]],
  ['tutorial_20training_20f32_537',['Tutorial training F32',['../_tutorial_training_f32.html',1,'']]]
];
