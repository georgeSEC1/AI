var searchData=
[
  ['aifes_5fe_5fadam_1091',['AIfES_E_adam',['../aifes__express__f32__fnn_8h.html#ac3fa2f42fb47ee5af7c7a3282d4f4cd0a4e1b034bc7b9050d2bf588d33cc31335',1,'aifes_express_f32_fnn.h']]],
  ['aifes_5fe_5fcrossentropy_1092',['AIfES_E_crossentropy',['../aifes__express__f32__fnn_8h.html#a9d5599ca9f2382ad1150d53f6ba8cbeaac01d593ae21e3f8bbe8c0587b016dcdf',1,'aifes_express_f32_fnn.h']]],
  ['aifes_5fe_5felu_1093',['AIfES_E_elu',['../aifes__express__f32__fnn_8h.html#a6dad88532ecc9bc7786bb69c0aab7c23ac682fe5e199bb2451b7bef2be8a55c4c',1,'aifes_express_f32_fnn.h']]],
  ['aifes_5fe_5finit_5fglorot_5funiform_1094',['AIfES_E_init_glorot_uniform',['../aifes__express__f32__fnn_8h.html#a35acc0093cf3f0ad28eb5c49b23d5e44af87a4fcba3d2e974db34883d63e763e6',1,'aifes_express_f32_fnn.h']]],
  ['aifes_5fe_5finit_5fno_5finit_1095',['AIfES_E_init_no_init',['../aifes__express__f32__fnn_8h.html#a35acc0093cf3f0ad28eb5c49b23d5e44a71b10c8f99beb2eadb896a33e5acb5eb',1,'aifes_express_f32_fnn.h']]],
  ['aifes_5fe_5finit_5funiform_1096',['AIfES_E_init_uniform',['../aifes__express__f32__fnn_8h.html#a35acc0093cf3f0ad28eb5c49b23d5e44aec06014a563924febf792beba6066e46',1,'aifes_express_f32_fnn.h']]],
  ['aifes_5fe_5fleaky_5frelu_1097',['AIfES_E_leaky_relu',['../aifes__express__f32__fnn_8h.html#a6dad88532ecc9bc7786bb69c0aab7c23a34502c83d13d257df268941d828f33f8',1,'aifes_express_f32_fnn.h']]],
  ['aifes_5fe_5flinear_1098',['AIfES_E_linear',['../aifes__express__f32__fnn_8h.html#a6dad88532ecc9bc7786bb69c0aab7c23af918200828e6049e46f83c0ca21db5b9',1,'aifes_express_f32_fnn.h']]],
  ['aifes_5fe_5fmse_1099',['AIfES_E_mse',['../aifes__express__f32__fnn_8h.html#a9d5599ca9f2382ad1150d53f6ba8cbeaaf095a896485970ce1b22f3e43fafb45a',1,'aifes_express_f32_fnn.h']]],
  ['aifes_5fe_5frelu_1100',['AIfES_E_relu',['../aifes__express__f32__fnn_8h.html#a6dad88532ecc9bc7786bb69c0aab7c23a90e8205e5c84ffb25fa38491b248b013',1,'aifes_express_f32_fnn.h']]],
  ['aifes_5fe_5fsgd_1101',['AIfES_E_sgd',['../aifes__express__f32__fnn_8h.html#ac3fa2f42fb47ee5af7c7a3282d4f4cd0a96fcd4b510ad51973f2fb6e380f98ad4',1,'aifes_express_f32_fnn.h']]],
  ['aifes_5fe_5fsigmoid_1102',['AIfES_E_sigmoid',['../aifes__express__f32__fnn_8h.html#a6dad88532ecc9bc7786bb69c0aab7c23a68c5b8166b0ec1f39f3f66eae44907d6',1,'aifes_express_f32_fnn.h']]],
  ['aifes_5fe_5fsoftmax_1103',['AIfES_E_softmax',['../aifes__express__f32__fnn_8h.html#a6dad88532ecc9bc7786bb69c0aab7c23a28fa45b9eb596a129f1be02bcebf9cf7',1,'aifes_express_f32_fnn.h']]],
  ['aifes_5fe_5fsoftsign_1104',['AIfES_E_softsign',['../aifes__express__f32__fnn_8h.html#a6dad88532ecc9bc7786bb69c0aab7c23ae2e92c9f3fdd4f778fffa154346c2213',1,'aifes_express_f32_fnn.h']]],
  ['aifes_5fe_5ftanh_1105',['AIfES_E_tanh',['../aifes__express__f32__fnn_8h.html#a6dad88532ecc9bc7786bb69c0aab7c23a7ca4f10620b8fca8ebf6e5d9a3ca4c98',1,'aifes_express_f32_fnn.h']]]
];
