var searchData=
[
  ['init_5foptimem_472',['init_optimem',['../structaiopti.html#a39e07b6004587fae3c9b12b1821ef066',1,'aiopti']]],
  ['init_5fweights_5fmethod_473',['init_weights_method',['../struct_a_i_f_e_s___e__init__weights__parameter__fnn__f32.html#a53ff47a067c37773857386dea83f220b',1,'AIFES_E_init_weights_parameter_fnn_f32']]],
  ['input_5fdim_474',['input_dim',['../structailayer__input.html#a79c751a08ece9acba83293880c3e062a',1,'ailayer_input']]],
  ['input_5flayer_475',['input_layer',['../structaimodel.html#a708a94e69112ad215b2b52da2238a711',1,'aimodel']]],
  ['input_5fshape_476',['input_shape',['../structailayer__input.html#a783daa03ac67ce4a58f74b1d3ad1f787',1,'ailayer_input']]]
];
