var searchData=
[
  ['layer_5fconfiguration_477',['layer_configuration',['../structailayer.html#a27d1eadee2654a2bd6e740eff4004ba8',1,'ailayer']]],
  ['layer_5fcount_478',['layer_count',['../struct_a_i_f_e_s___e__model__parameter__fnn__f32.html#a7c6673fb07eaacde14fefa8739cf81d9',1,'AIFES_E_model_parameter_fnn_f32::layer_count()'],['../structaimodel.html#a43c06bad78e81f2596a256d6455dfbdf',1,'aimodel::layer_count()']]],
  ['layer_5ftype_479',['layer_type',['../structailayer.html#a259a8d38509bfc89f5ff49b2a0d26b92',1,'ailayer']]],
  ['leaky_5frelu_480',['leaky_relu',['../structailayer__leaky__relu.html#adfec7e88122c57b43b8b572338e0fc08',1,'ailayer_leaky_relu']]],
  ['learn_5frate_481',['learn_rate',['../struct_a_i_f_e_s___e__training__parameter__fnn__f32.html#a057f27f74563c8ba830131c483b39902',1,'AIFES_E_training_parameter_fnn_f32']]],
  ['learning_5frate_482',['learning_rate',['../structaiopti.html#aafeaaeb2f574aee6bb461dac6bc9ddfb',1,'aiopti::learning_rate()'],['../structaiopti__sgd__q31.html#abcf8737c2bca79b703b5b2a1249fa797',1,'aiopti_sgd_q31::learning_rate()'],['../structaiopti__sgd__f32.html#a7fa6b6264ed55a45f7af8b00eae05f59',1,'aiopti_sgd_f32::learning_rate()'],['../structaiopti__adam__f32.html#a7fa6b6264ed55a45f7af8b00eae05f59',1,'aiopti_adam_f32::learning_rate()']]],
  ['linear_483',['linear',['../structailayer__dense.html#a7218a352357b1fb602775252d8286ce6',1,'ailayer_dense']]],
  ['loss_484',['loss',['../struct_a_i_f_e_s___e__training__parameter__fnn__f32.html#afc50e0264bae1a9eed729878ec54d6e4',1,'AIFES_E_training_parameter_fnn_f32::loss()'],['../structaimodel.html#ad08c61cef46d4042c62d8cdeba81986f',1,'aimodel::loss()']]],
  ['loss_5fconfiguration_485',['loss_configuration',['../structailoss.html#a3121ea3e968d07206c419b358a5cfafc',1,'ailoss']]],
  ['loss_5fprint_5ffunction_486',['loss_print_function',['../struct_a_i_f_e_s___e__training__parameter__fnn__f32.html#a395b877f575f44fcef603db0362368fc',1,'AIFES_E_training_parameter_fnn_f32']]],
  ['loss_5ftype_487',['loss_type',['../structailoss.html#abf49a46edc25393b8cf2d799861961ea',1,'ailoss']]],
  ['lrt_488',['lrt',['../structaiopti__adam.html#a8cd9a549bb8e806d57dfc672574fde8f',1,'aiopti_adam::lrt()'],['../structaiopti__adam__f32.html#a146379ac568942afe3a7519491ea6a2b',1,'aiopti_adam_f32::lrt()']]]
];
