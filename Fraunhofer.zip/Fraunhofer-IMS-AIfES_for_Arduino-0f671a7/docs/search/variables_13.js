var searchData=
[
  ['zero_5fgradients_1074',['zero_gradients',['../structaiopti.html#ae145c9527c45c9c98fe7a0b317245e66',1,'aiopti']]],
  ['zero_5fpoint_1075',['zero_point',['../structaimath__q31__params.html#a43cdb7ca657bf35ee727cdbae02fced9',1,'aimath_q31_params::zero_point()'],['../structaiscalar__q31.html#a43cdb7ca657bf35ee727cdbae02fced9',1,'aiscalar_q31::zero_point()'],['../structaimath__q7__params.html#a6a54cbe2eb02707d6e9ae6f12d539e1b',1,'aimath_q7_params::zero_point()'],['../structaiscalar__q7.html#a6a54cbe2eb02707d6e9ae6f12d539e1b',1,'aiscalar_q7::zero_point()']]],
  ['zero_5ftensor_1076',['zero_tensor',['../structaiopti__adam.html#aa0c5520df9a1bfa236b1ef7eddeb3553',1,'aiopti_adam::zero_tensor()'],['../structaiopti__sgd.html#aa0c5520df9a1bfa236b1ef7eddeb3553',1,'aiopti_sgd::zero_tensor()']]]
];
