var searchData=
[
  ['ailoss_5fcrossentropy_5ft_1077',['ailoss_crossentropy_t',['../ailoss__crossentropy_8h.html#a56ea9887c556a04a95748f51eb39cc6d',1,'ailoss_crossentropy.h']]],
  ['ailoss_5fmse_5ft_1078',['ailoss_mse_t',['../ailoss__mse_8h.html#a4ecc6690c6bbd44ac711d874609d9b30',1,'ailoss_mse.h']]],
  ['aiopti_5fadam_5fmomentums_5ft_1079',['aiopti_adam_momentums_t',['../aiopti__adam_8h.html#a40c00ead1bde1b1ac8c46282b0de8804',1,'aiopti_adam.h']]],
  ['aiopti_5fadam_5ft_1080',['aiopti_adam_t',['../aiopti__adam_8h.html#af6a2a8ada598e63f1be2ec6ff233c24f',1,'aiopti_adam.h']]],
  ['aiopti_5fsgd_5ff32_5ft_1081',['aiopti_sgd_f32_t',['../aiopti__sgd__default_8h.html#aa2deb6e151227ecf9683c4a4e356860e',1,'aiopti_sgd_default.h']]],
  ['aiopti_5fsgd_5fq31_5ft_1082',['aiopti_sgd_q31_t',['../aiopti__sgd__default_8h.html#a4cda85244ad3144d3e9bb146ea99b499',1,'aiopti_sgd_default.h']]],
  ['aiopti_5fsgd_5fq7_5ft_1083',['aiopti_sgd_q7_t',['../aiopti__sgd__default_8h.html#a6c5b1fd7098423a807d93067508705f8',1,'aiopti_sgd_default.h']]],
  ['aiopti_5fsgd_5ft_1084',['aiopti_sgd_t',['../aiopti__sgd_8h.html#a61b25438699bd6f918253a70b0e92973',1,'aiopti_sgd.h']]],
  ['aiscalar_5ff32_5ft_1085',['aiscalar_f32_t',['../aimath__f32_8h.html#ad3ffba87614778a1d8ee2314117ff59c',1,'aimath_f32.h']]]
];
