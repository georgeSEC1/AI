var structaiscalar__q31 =
[
    [ "shift", "structaiscalar__q31.html#a8f20d77488fe485aaf9ea8e9c5d7d35e", null ],
    [ "value", "structaiscalar__q31.html#a01571c420f280137c16d319178731da5", null ],
    [ "zero_point", "structaiscalar__q31.html#a43cdb7ca657bf35ee727cdbae02fced9", null ]
];