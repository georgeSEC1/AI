var ailoss__crossentropy_8h =
[
    [ "ailoss_crossentropy", "structailoss__crossentropy.html", "structailoss__crossentropy" ],
    [ "ailoss_crossentropy_t", "ailoss__crossentropy_8h.html#a56ea9887c556a04a95748f51eb39cc6d", null ],
    [ "ailoss_crossentropy", "ailoss__crossentropy_8h.html#a01fb5e844bd40d1318d29767ef9c4483", null ],
    [ "ailoss_crossentropy_calc_delta", "ailoss__crossentropy_8h.html#a0d3786e3889488435b149772729070b0", null ],
    [ "ailoss_crossentropy_calc_loss", "ailoss__crossentropy_8h.html#a7609a343755d8e7ac3edba32aeced667", null ],
    [ "ailoss_crossentropy_dummy_backward", "ailoss__crossentropy_8h.html#a6495ab52d2d6911f27ad06a6431f2f0a", null ],
    [ "ailoss_crossentropy_print_specs", "ailoss__crossentropy_8h.html#aade66fe1598961b028615f1397c51720", null ],
    [ "ailoss_crossentropy_type", "ailoss__crossentropy_8h.html#a6efcc57d18e614d7745ee381254e0545", null ]
];