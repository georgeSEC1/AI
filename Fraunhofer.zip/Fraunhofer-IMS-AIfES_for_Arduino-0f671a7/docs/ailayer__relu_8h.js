var ailayer__relu_8h =
[
    [ "ailayer_relu", "structailayer__relu.html", "structailayer__relu" ],
    [ "ailayer_relu_t", "ailayer__relu_8h.html#a98db961de58a55f8dc8469ac02bd3480", null ],
    [ "ailayer_relu", "ailayer__relu_8h.html#a54f1a21cb4a0714fe54d2a446bfe8424", null ],
    [ "ailayer_relu_backward", "ailayer__relu_8h.html#ab2401e9f8513a088f84eb8cef3b5a1a1", null ],
    [ "ailayer_relu_calc_result_shape", "ailayer__relu_8h.html#ae5725b5af970de000d58cb13c43d3ba2", null ],
    [ "ailayer_relu_forward", "ailayer__relu_8h.html#a178711a21fd2f8f43d4942bb3435b8f8", null ],
    [ "ailayer_relu_print_specs", "ailayer__relu_8h.html#acaea6f1b3be61f91330c1a25d57892ab", null ],
    [ "ailayer_relu_type", "ailayer__relu_8h.html#a5b239b84a59fbae4016ea97cf0024689", null ]
];