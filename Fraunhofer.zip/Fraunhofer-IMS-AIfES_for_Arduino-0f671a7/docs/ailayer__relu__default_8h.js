var ailayer__relu__default_8h =
[
    [ "ailayer_relu_f32_t", "ailayer__relu__default_8h.html#a044dde978f3a011547326325f9eb0d2e", null ],
    [ "ailayer_relu_q31_t", "ailayer__relu__default_8h.html#a413b5c30d811f6f54705d16a7d0e6d85", null ],
    [ "ailayer_relu_q7_t", "ailayer__relu__default_8h.html#a5e881ebdbed9a5844bb6484910eea41d", null ],
    [ "ailayer_relu_calc_result_tensor_params_q31_default", "ailayer__relu__default_8h.html#a45accd90089c39faf7db792cf386fe73", null ],
    [ "ailayer_relu_calc_result_tensor_params_q7_default", "ailayer__relu__default_8h.html#a62c105ce60754c28eaf01e0a253b46b9", null ],
    [ "ailayer_relu_f32_default", "ailayer__relu__default_8h.html#aa5997c9081cc6a6d1bf11154e4062526", null ],
    [ "ailayer_relu_q31_default", "ailayer__relu__default_8h.html#a1c81d668775b7729451aaced412206da", null ],
    [ "ailayer_relu_q7_default", "ailayer__relu__default_8h.html#a4c88d45b618f28ebcfb3e84c00ca4e06", null ]
];