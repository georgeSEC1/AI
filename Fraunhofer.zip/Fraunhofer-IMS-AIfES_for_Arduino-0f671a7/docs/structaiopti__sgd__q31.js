var structaiopti__sgd__q31 =
[
    [ "base", "structaiopti__sgd__q31.html#a270f88050869a0d88e82be3615473b37", null ],
    [ "learning_rate", "structaiopti__sgd__q31.html#abcf8737c2bca79b703b5b2a1249fa797", null ],
    [ "momentum", "structaiopti__sgd__q31.html#a2f7d2e5e4cde9ec10f5bc5945ca157bf", null ]
];