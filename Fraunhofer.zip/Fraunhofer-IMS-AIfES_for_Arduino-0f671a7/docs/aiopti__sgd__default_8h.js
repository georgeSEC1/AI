var aiopti__sgd__default_8h =
[
    [ "aiopti_sgd_f32", "structaiopti__sgd__f32.html", "structaiopti__sgd__f32" ],
    [ "aiopti_sgd_q31", "structaiopti__sgd__q31.html", "structaiopti__sgd__q31" ],
    [ "aiopti_sgd_f32_t", "aiopti__sgd__default_8h.html#aa2deb6e151227ecf9683c4a4e356860e", null ],
    [ "aiopti_sgd_q31_t", "aiopti__sgd__default_8h.html#a4cda85244ad3144d3e9bb146ea99b499", null ],
    [ "aiopti_sgd_q7_t", "aiopti__sgd__default_8h.html#a6c5b1fd7098423a807d93067508705f8", null ],
    [ "aiopti_sgd_f32_default", "aiopti__sgd__default_8h.html#a03d6b243e9d19878cf5c4d53c6e892ce", null ],
    [ "aiopti_sgd_q31_default", "aiopti__sgd__default_8h.html#a68b634f26ac2d6408ea8f75487fed03b", null ]
];