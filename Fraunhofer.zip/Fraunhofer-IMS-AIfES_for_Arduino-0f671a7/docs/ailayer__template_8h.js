var ailayer__template_8h =
[
    [ "ailayer_template", "structailayer__template.html", "structailayer__template" ],
    [ "ailayer_template_t", "ailayer__template_8h.html#a6936bc92fd214fa57f8fa766ac065581", null ],
    [ "ailayer_template", "ailayer__template_8h.html#a877916ceae42ff18b06bcbae07ee0908", null ],
    [ "ailayer_template_backward", "ailayer__template_8h.html#af5752cd98ed4d72cc9b785e9b62442b3", null ],
    [ "ailayer_template_calc_result_shape", "ailayer__template_8h.html#a187b2d82e879cd883f94c18b85cd6d5a", null ],
    [ "ailayer_template_forward", "ailayer__template_8h.html#acee3a4d7c24c145edd2adc193a2986d4", null ],
    [ "ailayer_template_print_specs", "ailayer__template_8h.html#a15aae05c03815f718ceec7017f3a52bd", null ],
    [ "ailayer_template_set_paramem", "ailayer__template_8h.html#a7f438a2288e4fd51ffac82ebbc048ff0", null ],
    [ "ailayer_template_set_trainmem", "ailayer__template_8h.html#a23a312f2bbe3a375c3f9531943e1aa99", null ],
    [ "ailayer_template_sizeof_paramem", "ailayer__template_8h.html#a567a02d0b5013e1dbec32751415a4c75", null ],
    [ "ailayer_template_sizeof_trainmem", "ailayer__template_8h.html#af928b71fdfe94a4e5bed3df2fc1f5f37", null ],
    [ "ailayer_template_type", "ailayer__template_8h.html#a22c2e7fdb8c727c7f75680691b0849b8", null ]
];