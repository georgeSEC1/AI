var structaiopti__adam__f32 =
[
    [ "base", "structaiopti__adam__f32.html#a4ee5aa66748dc3de06264edf611afe36", null ],
    [ "beta1", "structaiopti__adam__f32.html#a1eefe694094134546744d852c420f795", null ],
    [ "beta1t", "structaiopti__adam__f32.html#a86ca477df4949ba19f88dff95881f2fd", null ],
    [ "beta2", "structaiopti__adam__f32.html#a6f91825b1fa3d8852229565300d0120d", null ],
    [ "beta2t", "structaiopti__adam__f32.html#a84f5411ba7618657a0d5a2d155f62eae", null ],
    [ "eps", "structaiopti__adam__f32.html#ab7512d520c28ccb5fe079e9767abbe2f", null ],
    [ "learning_rate", "structaiopti__adam__f32.html#a7fa6b6264ed55a45f7af8b00eae05f59", null ],
    [ "lrt", "structaiopti__adam__f32.html#a146379ac568942afe3a7519491ea6a2b", null ],
    [ "one_minus_beta1", "structaiopti__adam__f32.html#a02e260a8f1cec862011a285d8af0f9f7", null ],
    [ "one_minus_beta2", "structaiopti__adam__f32.html#a6cf0c7e58cbeaa620a0323eca2176871", null ]
];