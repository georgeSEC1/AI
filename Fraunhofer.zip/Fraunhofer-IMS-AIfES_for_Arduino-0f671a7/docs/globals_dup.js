var globals_dup =
[
    [ "a", "globals.html", null ],
    [ "p", "globals_p.html", null ]
];