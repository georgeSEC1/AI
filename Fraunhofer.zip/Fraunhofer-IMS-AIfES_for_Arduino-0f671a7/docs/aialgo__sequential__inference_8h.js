var aialgo__sequential__inference_8h =
[
    [ "aialgo_compile_model", "aialgo__sequential__inference_8h.html#a3fb665166082f1e7a89e23218a105ce8", null ],
    [ "aialgo_distribute_parameter_memory", "aialgo__sequential__inference_8h.html#a26db68cb4231b534b03c649d6eeab3f8", null ],
    [ "aialgo_forward_model", "aialgo__sequential__inference_8h.html#a4655caab3051cc837312c286fbe4789a", null ],
    [ "aialgo_inference_model", "aialgo__sequential__inference_8h.html#aafaea85e93de468925ada90c77494eec", null ],
    [ "aialgo_print_model_structure", "aialgo__sequential__inference_8h.html#a3bb5fdb556c51ad8b3043d220f0a1276", null ],
    [ "aialgo_quantize_model_f32_to_q7", "aialgo__sequential__inference_8h.html#a07f280b3565ec1b02f00d907a2834940", null ],
    [ "aialgo_schedule_inference_memory", "aialgo__sequential__inference_8h.html#a7cbfac6a46c02107d19af7c8f6e5469a", null ],
    [ "aialgo_set_model_delta_precision_q31", "aialgo__sequential__inference_8h.html#a4d70260b376741a0cef4c42d41e705f8", null ],
    [ "aialgo_set_model_gradient_precision_q31", "aialgo__sequential__inference_8h.html#a436e4f31e3a5498d033917db8277ff55", null ],
    [ "aialgo_set_model_result_precision_q31", "aialgo__sequential__inference_8h.html#a0b1aae54861650b0d6e80fc638a0b0ea", null ],
    [ "aialgo_sizeof_inference_memory", "aialgo__sequential__inference_8h.html#a877ce6eee19a9f9bcbdb115d83537e68", null ],
    [ "aialgo_sizeof_parameter_memory", "aialgo__sequential__inference_8h.html#acdf3763b8fe9047446ddbcfdbdae5570", null ]
];