var ailayer__sigmoid__default_8h =
[
    [ "ailayer_sigmoid_f32_t", "ailayer__sigmoid__default_8h.html#a6f282e01b67becc4d6cc0a826d48e284", null ],
    [ "ailayer_sigmoid_q31_t", "ailayer__sigmoid__default_8h.html#a747489dd099392f7b46b7b1f0ae31102", null ],
    [ "ailayer_sigmoid_q7_t", "ailayer__sigmoid__default_8h.html#a906811fa1332672764393ae81397c7df", null ],
    [ "ailayer_sigmoid_calc_result_tensor_params_q31_default", "ailayer__sigmoid__default_8h.html#a88f5d3306d9cdb985c9fc0f9dcd1d6c4", null ],
    [ "ailayer_sigmoid_calc_result_tensor_params_q7_default", "ailayer__sigmoid__default_8h.html#a79fb15d39afc5e75e33944db370b2152", null ],
    [ "ailayer_sigmoid_f32_default", "ailayer__sigmoid__default_8h.html#a1ec45b121e81b85e2109f0072d46f602", null ],
    [ "ailayer_sigmoid_q31_default", "ailayer__sigmoid__default_8h.html#a4174af2abb3a361144f00ba7521ee114", null ],
    [ "ailayer_sigmoid_q7_default", "ailayer__sigmoid__default_8h.html#ad6c8e7d5957c33998ab12847b651e263", null ]
];