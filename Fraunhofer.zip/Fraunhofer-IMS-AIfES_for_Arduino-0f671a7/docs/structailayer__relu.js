var structailayer__relu =
[
    [ "base", "structailayer__relu.html#ab13782a46e3804246bf82a92955096b3", null ],
    [ "d_relu", "structailayer__relu.html#a9ecbdfe6b09d45308df2145094445ab9", null ],
    [ "dtype", "structailayer__relu.html#abf7a461af7296a09d5246ca13591b988", null ],
    [ "multiply", "structailayer__relu.html#a50f5e44b0fca9c1e79a5287adb4a59eb", null ],
    [ "relu", "structailayer__relu.html#aa86168e5f130c59eacbedb95be431aab", null ]
];