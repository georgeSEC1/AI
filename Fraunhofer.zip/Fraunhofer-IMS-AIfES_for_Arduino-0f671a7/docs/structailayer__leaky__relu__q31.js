var structailayer__leaky__relu__q31 =
[
    [ "alpha", "structailayer__leaky__relu__q31.html#a98cbddd039b1fda205f88087073f43da", null ],
    [ "base", "structailayer__leaky__relu__q31.html#a9a2a16f59298403e82b95dd4f9ab9865", null ]
];