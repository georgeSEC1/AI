var structailayer__template =
[
    [ "base", "structailayer__template.html#ab13782a46e3804246bf82a92955096b3", null ],
    [ "copy_tensor", "structailayer__template.html#a83c24bfde9518ea3fca2ed9ab785d59a", null ],
    [ "d_params", "structailayer__template.html#ac8bc9b9715271b7e6cde719919e2b519", null ],
    [ "dtype", "structailayer__template.html#abf7a461af7296a09d5246ca13591b988", null ],
    [ "example_configuration", "structailayer__template.html#aa5d7c0b30e5c7158a2f8fe2e7d8881d1", null ],
    [ "gradients", "structailayer__template.html#a33b189c78566d57ad498dbf2cc364917", null ],
    [ "optimem", "structailayer__template.html#a590c48e998a8a740439e38d0aa4302dd", null ],
    [ "params", "structailayer__template.html#ac7787b50288a121497b4a4e26dd41e54", null ],
    [ "result_shape", "structailayer__template.html#ab733a6d9451ea97c43c593a495f26d51", null ],
    [ "tensor_add", "structailayer__template.html#a7674445f16490c6cacdb03157feab8c7", null ],
    [ "trainable_params", "structailayer__template.html#afcc6c64ff572ae7408fe1c4bcfe7b9d1", null ]
];