var globals_func =
[
    [ "a", "globals_func.html", null ],
    [ "p", "globals_func_p.html", null ]
];