var ailayer__sigmoid_8h =
[
    [ "ailayer_sigmoid", "structailayer__sigmoid.html", "structailayer__sigmoid" ],
    [ "ailayer_sigmoid_t", "ailayer__sigmoid_8h.html#a0ca7bc6ba0f10e249e775371795715c6", null ],
    [ "ailayer_sigmoid", "ailayer__sigmoid_8h.html#a5984bf3aeaba41a15112a8ad1ef966b5", null ],
    [ "ailayer_sigmoid_backward", "ailayer__sigmoid_8h.html#a39556aa19ebba788cd613d95af3a84b5", null ],
    [ "ailayer_sigmoid_calc_result_shape", "ailayer__sigmoid_8h.html#ac8b3179554261f9cb3dbf4036e18a265", null ],
    [ "ailayer_sigmoid_forward", "ailayer__sigmoid_8h.html#ab5a23b1b7f461f68a7b837de750a0a9a", null ],
    [ "ailayer_sigmoid_print_specs", "ailayer__sigmoid_8h.html#aaffb52a6758b928c235ccb91e5032aac", null ],
    [ "ailayer_sigmoid_type", "ailayer__sigmoid_8h.html#a054619411993c0f800a981a5511b1aa4", null ]
];