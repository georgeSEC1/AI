var structailayer__elu__q31 =
[
    [ "alpha", "structailayer__elu__q31.html#a98cbddd039b1fda205f88087073f43da", null ],
    [ "base", "structailayer__elu__q31.html#a6d80585658fb6a5a14c46fefd49ac0ba", null ]
];