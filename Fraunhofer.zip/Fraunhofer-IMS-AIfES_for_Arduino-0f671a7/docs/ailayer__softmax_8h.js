var ailayer__softmax_8h =
[
    [ "ailayer_softmax", "structailayer__softmax.html", "structailayer__softmax" ],
    [ "ailayer_softmax_t", "ailayer__softmax_8h.html#ac96046777d76de1a61e7058d4afadb1c", null ],
    [ "ailayer_softmax", "ailayer__softmax_8h.html#a655e0fbe0cc780cd94f6f68b937d183d", null ],
    [ "ailayer_softmax_calc_result_shape", "ailayer__softmax_8h.html#a025c5fa39aa132c355e1d17520168539", null ],
    [ "ailayer_softmax_forward", "ailayer__softmax_8h.html#a8637d55cbec2ed012f66436c4c1d2d89", null ],
    [ "ailayer_softmax_print_specs", "ailayer__softmax_8h.html#acd0b7d7ae0c9bcd58290c0041f2832e1", null ],
    [ "ailayer_softmax_type", "ailayer__softmax_8h.html#a39ccc479c8ce0777648e80fb7331bc8a", null ]
];