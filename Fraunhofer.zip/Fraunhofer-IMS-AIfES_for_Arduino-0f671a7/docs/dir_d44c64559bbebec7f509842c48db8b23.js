var dir_d44c64559bbebec7f509842c48db8b23 =
[
    [ "basic", "dir_1e5d3661ed79af157d57e64a38265d09.html", "dir_1e5d3661ed79af157d57e64a38265d09" ],
    [ "core", "dir_3d69f64eaf81436fe2b22361382717e5.html", "dir_3d69f64eaf81436fe2b22361382717e5" ]
];