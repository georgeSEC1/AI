var aifes__express__q7__fnn_8h =
[
    [ "AIFES_E_flat_weights_number_fnn_q7", "aifes__express__q7__fnn_8h.html#ac543551279494c6ce9709e4ee6f59104", null ],
    [ "AIFES_E_inference_fnn_q7", "aifes__express__q7__fnn_8h.html#a2bf3d2e767a7a1d9bef8a1a179e7324a", null ],
    [ "AIFES_E_quantisation_fnn_f32_to_q7", "aifes__express__q7__fnn_8h.html#a0518e913814f0ab2f04f75f3d47c495e", null ]
];