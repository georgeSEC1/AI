var dir_bd8ee926357880309e83f96383a42e12 =
[
    [ "aialgo_sequential_inference.h", "aialgo__sequential__inference_8h.html", "aialgo__sequential__inference_8h" ],
    [ "aialgo_sequential_training.h", "aialgo__sequential__training_8h.html", "aialgo__sequential__training_8h" ]
];