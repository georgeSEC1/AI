var ailayer__softmax__avr__pgm_8h =
[
    [ "ailayer_softmax_q7_avr_pgm", "ailayer__softmax__avr__pgm_8h.html#ad8b7643c2fa2e9310dc516935f86fca6", null ]
];