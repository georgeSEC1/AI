var ailayer__sigmoid__avr__pgm_8h =
[
    [ "ailayer_sigmoid_q7_avr_pgm", "ailayer__sigmoid__avr__pgm_8h.html#a8c5b9369bc78a5c2c70ab21877d860e4", null ]
];