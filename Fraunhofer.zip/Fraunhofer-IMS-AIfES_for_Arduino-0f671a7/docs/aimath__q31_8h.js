var aimath__q31_8h =
[
    [ "aimath_q31_params", "structaimath__q31__params.html", "structaimath__q31__params" ],
    [ "aiscalar_q31", "structaiscalar__q31.html", "structaiscalar__q31" ],
    [ "aimath_q31_params_t", "aimath__q31_8h.html#a3f46d45ebbddd88260888a25e5279924", null ],
    [ "aiscalar_q31_t", "aimath__q31_8h.html#a1a39892302b6eb71fcbe5e3af4f0bbc6", null ],
    [ "aimath_q31_calc_q_params_from_f32", "aimath__q31_8h.html#a3e5faeb8c077d061d6e8d48543b947c5", null ],
    [ "aimath_q31_print_aiscalar", "aimath__q31_8h.html#a7359acc9b475f46d48ce80ef7c74114f", null ],
    [ "aimath_q31_print_aitensor", "aimath__q31_8h.html#a541e04ea103af9dbbd9ec41934dbf2af", null ],
    [ "aimath_q31_quantize_tensor_from_f32", "aimath__q31_8h.html#ac204ae3be0fdc2b0ac57369254c58f1a", null ],
    [ "aiq31", "aimath__q31_8h.html#ac5314582da98b2cdbe4b445ea25f0b77", null ]
];