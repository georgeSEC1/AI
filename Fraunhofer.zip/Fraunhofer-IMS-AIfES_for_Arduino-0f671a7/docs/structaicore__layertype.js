var structaicore__layertype =
[
    [ "name", "structaicore__layertype.html#a8f8f80d37794cde9472343e4487ba3eb", null ],
    [ "print_specs", "structaicore__layertype.html#a00bc72ab6d23f7ad53b92a8c64484b18", null ]
];