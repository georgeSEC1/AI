var ailayer__tanh__default_8h =
[
    [ "ailayer_tanh_f32_t", "ailayer__tanh__default_8h.html#af8b513eec341fe4dc829ca63bd282622", null ],
    [ "ailayer_tanh_q31_t", "ailayer__tanh__default_8h.html#a393de6ba13b8e0f9c0c64cbbfa489d7e", null ],
    [ "ailayer_tanh_q7_t", "ailayer__tanh__default_8h.html#aed1778629f6eba250a81a2cddc6495ed", null ],
    [ "ailayer_tanh_calc_result_tensor_params_q31_default", "ailayer__tanh__default_8h.html#afb52b10c0d1180b5d4b45a6dc02c7b14", null ],
    [ "ailayer_tanh_calc_result_tensor_params_q7_default", "ailayer__tanh__default_8h.html#af23f7e1a52355597785cd038901c134c", null ],
    [ "ailayer_tanh_f32_default", "ailayer__tanh__default_8h.html#a80b4a962ca942bf21c936b66ea8ad948", null ],
    [ "ailayer_tanh_q31_default", "ailayer__tanh__default_8h.html#a07522d6a43bd3ee674737697fcf191a6", null ],
    [ "ailayer_tanh_q7_default", "ailayer__tanh__default_8h.html#ac27a188a1d716d8d1fa04469bdeccc87", null ]
];