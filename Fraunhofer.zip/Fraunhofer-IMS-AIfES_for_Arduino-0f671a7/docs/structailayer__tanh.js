var structailayer__tanh =
[
    [ "base", "structailayer__tanh.html#ab13782a46e3804246bf82a92955096b3", null ],
    [ "d_tanh", "structailayer__tanh.html#a42dec6b025b13da223c8a8697f1c5d31", null ],
    [ "dtype", "structailayer__tanh.html#abf7a461af7296a09d5246ca13591b988", null ],
    [ "multiply", "structailayer__tanh.html#a50f5e44b0fca9c1e79a5287adb4a59eb", null ],
    [ "tanh", "structailayer__tanh.html#a044094cf164cf12ae0a5cc682dfc9804", null ]
];