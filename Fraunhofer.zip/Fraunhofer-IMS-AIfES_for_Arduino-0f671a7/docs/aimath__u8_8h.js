var aimath__u8_8h =
[
    [ "aiscalar_u8_t", "aimath__u8_8h.html#aaa3a7a02e3b93e3de8961d45dcdeb48c", null ],
    [ "aimath_u8_print_aiscalar", "aimath__u8_8h.html#ac900c82008b1e66c136af5612cd55ab3", null ],
    [ "aimath_u8_print_aitensor", "aimath__u8_8h.html#ab6756152ecb5fff349334077a54dc18a", null ],
    [ "aiu8", "aimath__u8_8h.html#a4a9f54b27fd4cf6f271240217a6d764c", null ]
];