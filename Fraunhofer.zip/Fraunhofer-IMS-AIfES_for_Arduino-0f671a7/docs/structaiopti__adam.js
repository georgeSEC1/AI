var structaiopti__adam =
[
    [ "base", "structaiopti__adam.html#a76e9fa4cf381a685a5df819a57737e64", null ],
    [ "beta1", "structaiopti__adam.html#afe398d9948a5b913323c75e15d752a21", null ],
    [ "beta1t", "structaiopti__adam.html#a776f34e8b0d6f0a734f7bd69911f8115", null ],
    [ "beta2", "structaiopti__adam.html#a929c5cadde02d656d5a6c16c3a225a9f", null ],
    [ "beta2t", "structaiopti__adam.html#a8969b6b3c91318044af66d9829fcc981", null ],
    [ "divide", "structaiopti__adam.html#a5c1478e75fa8c703a1ed25b1091a6bc4", null ],
    [ "eps", "structaiopti__adam.html#a642324fdce94ffd7d353846649fd5c3f", null ],
    [ "lrt", "structaiopti__adam.html#a8cd9a549bb8e806d57dfc672574fde8f", null ],
    [ "multiply", "structaiopti__adam.html#a50f5e44b0fca9c1e79a5287adb4a59eb", null ],
    [ "one_minus_beta1", "structaiopti__adam.html#a508e23c3b1a359c4dc09fd4aca55b5be", null ],
    [ "one_minus_beta2", "structaiopti__adam.html#a6a78981ba0fc6b6c94018fbbf550eeae", null ],
    [ "scalar_add", "structaiopti__adam.html#a5aaf0a1aa2e5c1674e5b4be2f80f907f", null ],
    [ "scalar_mul", "structaiopti__adam.html#a2cbbfaac40611a8dd0ec908cc199b388", null ],
    [ "sqrt", "structaiopti__adam.html#a5d36deab4e71dd3b8d45ea2fff8f4b55", null ],
    [ "tensor_add", "structaiopti__adam.html#a7674445f16490c6cacdb03157feab8c7", null ],
    [ "tensor_sub", "structaiopti__adam.html#a5f5b55cad6c306233a8e4510d1773244", null ],
    [ "zero_tensor", "structaiopti__adam.html#aa0c5520df9a1bfa236b1ef7eddeb3553", null ]
];