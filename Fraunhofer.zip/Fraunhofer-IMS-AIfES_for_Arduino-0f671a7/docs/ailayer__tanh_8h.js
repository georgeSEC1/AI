var ailayer__tanh_8h =
[
    [ "ailayer_tanh", "structailayer__tanh.html", "structailayer__tanh" ],
    [ "ailayer_tanh_t", "ailayer__tanh_8h.html#a3c69ea9b7609356996bb2eaf4f981b89", null ],
    [ "ailayer_tanh", "ailayer__tanh_8h.html#a3c100d792dd25092cff5f14bfea3ec94", null ],
    [ "ailayer_tanh_backward", "ailayer__tanh_8h.html#ac477848c5933f2272ca5bde9d3f7f488", null ],
    [ "ailayer_tanh_calc_result_shape", "ailayer__tanh_8h.html#acd79a0ed7830bdbbcae6abfd9afa3551", null ],
    [ "ailayer_tanh_forward", "ailayer__tanh_8h.html#a82463c6aa5e8d1f94fb1a264412e0e36", null ],
    [ "ailayer_tanh_print_specs", "ailayer__tanh_8h.html#aeffd74a2c7b34491fb2a77305608bee4", null ],
    [ "ailayer_tanh_type", "ailayer__tanh_8h.html#a199dcc8608b90dde65c0c54b949957f7", null ]
];