var structaiopti__sgd__f32 =
[
    [ "base", "structaiopti__sgd__f32.html#a270f88050869a0d88e82be3615473b37", null ],
    [ "learning_rate", "structaiopti__sgd__f32.html#a7fa6b6264ed55a45f7af8b00eae05f59", null ],
    [ "momentum", "structaiopti__sgd__f32.html#ac5a20618f5afb39efca892de7a2b68c6", null ]
];