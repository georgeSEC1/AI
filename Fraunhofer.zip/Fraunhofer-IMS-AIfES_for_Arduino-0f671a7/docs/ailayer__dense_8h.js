var ailayer__dense_8h =
[
    [ "ailayer_dense", "structailayer__dense.html", "structailayer__dense" ],
    [ "ailayer_dense_t", "ailayer__dense_8h.html#a2efb175179411e3a0f141a36c6405460", null ],
    [ "ailayer_dense", "ailayer__dense_8h.html#a55f934a56796ad95ed1c84872a60036a", null ],
    [ "ailayer_dense_backward", "ailayer__dense_8h.html#a5e277ec1fb19ee7bf5ff5739e1ff602b", null ],
    [ "ailayer_dense_calc_result_shape", "ailayer__dense_8h.html#af5b9c869c1fa531d97c4552260a281bb", null ],
    [ "ailayer_dense_forward", "ailayer__dense_8h.html#a60a37f3b0d587837a4009493358a9099", null ],
    [ "ailayer_dense_print_specs", "ailayer__dense_8h.html#a24f794b27b7f95f1d7bb37d3d644709b", null ],
    [ "ailayer_dense_set_paramem", "ailayer__dense_8h.html#a53080c62efc7018b712b45cf12b1752c", null ],
    [ "ailayer_dense_set_trainmem", "ailayer__dense_8h.html#a6958d4d1d0e04b3956439d376eba68a6", null ],
    [ "ailayer_dense_sizeof_paramem", "ailayer__dense_8h.html#acbf46397f7de94812d143bce76e242e9", null ],
    [ "ailayer_dense_sizeof_trainmem", "ailayer__dense_8h.html#a805ebc0bc547e269a66cda967d6cf078", null ],
    [ "ailayer_dense_type", "ailayer__dense_8h.html#a1746227a13e65de07c7b7be8a0b8e8f8", null ]
];