var structailayer__input =
[
    [ "base", "structailayer__input.html#ab13782a46e3804246bf82a92955096b3", null ],
    [ "dtype", "structailayer__input.html#abf7a461af7296a09d5246ca13591b988", null ],
    [ "input_dim", "structailayer__input.html#a79c751a08ece9acba83293880c3e062a", null ],
    [ "input_shape", "structailayer__input.html#a783daa03ac67ce4a58f74b1d3ad1f787", null ]
];