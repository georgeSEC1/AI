var structailayer__leaky__relu__q7 =
[
    [ "alpha", "structailayer__leaky__relu__q7.html#a539517a0a6e01c1f0a5e15426efe6a49", null ],
    [ "base", "structailayer__leaky__relu__q7.html#a9a2a16f59298403e82b95dd4f9ab9865", null ]
];