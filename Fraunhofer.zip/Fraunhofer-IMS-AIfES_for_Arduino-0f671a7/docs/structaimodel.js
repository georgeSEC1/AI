var structaimodel =
[
    [ "input_layer", "structaimodel.html#a708a94e69112ad215b2b52da2238a711", null ],
    [ "layer_count", "structaimodel.html#a43c06bad78e81f2596a256d6455dfbdf", null ],
    [ "loss", "structaimodel.html#ad08c61cef46d4042c62d8cdeba81986f", null ],
    [ "output_layer", "structaimodel.html#a7c7ad89e7d15631b3f5893b8f19030ef", null ],
    [ "trainable_params_count", "structaimodel.html#a0ccfc06a73c9325540dea85791a1e36b", null ]
];