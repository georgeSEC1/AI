var structaimath__q31__params =
[
    [ "shift", "structaimath__q31__params.html#a8f20d77488fe485aaf9ea8e9c5d7d35e", null ],
    [ "zero_point", "structaimath__q31__params.html#a43cdb7ca657bf35ee727cdbae02fced9", null ]
];