var structaiscalar__q7 =
[
    [ "shift", "structaiscalar__q7.html#a8f20d77488fe485aaf9ea8e9c5d7d35e", null ],
    [ "value", "structaiscalar__q7.html#af6cd29ae1beb8f0d3e03c9824b5ffa63", null ],
    [ "zero_point", "structaiscalar__q7.html#a6a54cbe2eb02707d6e9ae6f12d539e1b", null ]
];