var structailayer =
[
    [ "backward", "structailayer.html#a235e06f76bc9641b9c9b95ae29b56fe9", null ],
    [ "calc_result_shape", "structailayer.html#a66787e37cfd371070476221e86386f7c", null ],
    [ "calc_result_tensor_params", "structailayer.html#ab5e8fd65efe85a1ee1ac9147594ddd61", null ],
    [ "deltas", "structailayer.html#a6e0cd193754d9614d5da823f0f0fcbf6", null ],
    [ "forward", "structailayer.html#a5fbd0ec6a416b01399233d98e60ca060", null ],
    [ "gradients", "structailayer.html#adf565818ce1d94c39e818326a25a6de8", null ],
    [ "input_layer", "structailayer.html#a708a94e69112ad215b2b52da2238a711", null ],
    [ "layer_configuration", "structailayer.html#a27d1eadee2654a2bd6e740eff4004ba8", null ],
    [ "layer_type", "structailayer.html#a259a8d38509bfc89f5ff49b2a0d26b92", null ],
    [ "next_scheduled", "structailayer.html#a47213b2dc55647e7c77da67e90efbe14", null ],
    [ "optimem", "structailayer.html#a0d7d5229bb3c514d7bd3e2bcf40c5f5a", null ],
    [ "output_layer", "structailayer.html#a7c7ad89e7d15631b3f5893b8f19030ef", null ],
    [ "prev_scheduled", "structailayer.html#a966bd2917b6b8822e40467269cc30ce4", null ],
    [ "result", "structailayer.html#a1ed86d1fec7aae68bc79c55f3f965790", null ],
    [ "set_paramem", "structailayer.html#a219921bd3b75e98894a33f6c2ff61c07", null ],
    [ "set_trainmem", "structailayer.html#a5062b6bf991a3ae278941c560847eeb6", null ],
    [ "sizeof_paramem", "structailayer.html#ab758b2be3966c7cc0bf6920a60886bbf", null ],
    [ "sizeof_trainmem", "structailayer.html#af95ecd0e925bff73b30b1d1b6fc21028", null ],
    [ "trainable_params", "structailayer.html#a8a3410d74de23e53ffb75649fec0851a", null ],
    [ "trainable_params_count", "structailayer.html#a328cb32bcb611f02ace7da86ab9711a2", null ]
];