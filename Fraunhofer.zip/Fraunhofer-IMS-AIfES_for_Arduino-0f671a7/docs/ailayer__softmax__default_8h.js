var ailayer__softmax__default_8h =
[
    [ "ailayer_softmax_f32_t", "ailayer__softmax__default_8h.html#a69e8b2dfeb3385e3268344f8089b3bd7", null ],
    [ "ailayer_softmax_q31_t", "ailayer__softmax__default_8h.html#aea73c1b35eebebdc7c865e81d9ff462a", null ],
    [ "ailayer_softmax_q7_t", "ailayer__softmax__default_8h.html#aa142629de588623499e874d58f249727", null ],
    [ "ailayer_softmax_calc_result_tensor_params_q31_default", "ailayer__softmax__default_8h.html#a8037b9cd851dd10f715f113107ad8c6b", null ],
    [ "ailayer_softmax_calc_result_tensor_params_q7_default", "ailayer__softmax__default_8h.html#abc1623eb58ecc09009b80f3843a972eb", null ],
    [ "ailayer_softmax_f32_default", "ailayer__softmax__default_8h.html#a3a89bb8691ee208550e0b267355679ea", null ],
    [ "ailayer_softmax_q31_default", "ailayer__softmax__default_8h.html#aabdf9e2b722406165c4e28a0c8c29a18", null ],
    [ "ailayer_softmax_q7_default", "ailayer__softmax__default_8h.html#a469403b690f21b4025bd5443bf6af11d", null ]
];