var structaiopti =
[
    [ "begin_step", "structaiopti.html#a5b82d583ac0602253e07aaea992d4e3f", null ],
    [ "dtype", "structaiopti.html#abf7a461af7296a09d5246ca13591b988", null ],
    [ "end_step", "structaiopti.html#ae52778f5409e29c7f25cc4ee9ff66f55", null ],
    [ "init_optimem", "structaiopti.html#a39e07b6004587fae3c9b12b1821ef066", null ],
    [ "learning_rate", "structaiopti.html#aafeaaeb2f574aee6bb461dac6bc9ddfb", null ],
    [ "optimizer_configuration", "structaiopti.html#a137684e527116392d2672299bc93b95c", null ],
    [ "optimizer_type", "structaiopti.html#a6ca0fdd2169bc462e1cc4f87e786933d", null ],
    [ "sizeof_optimem", "structaiopti.html#a948b4e86692cb9306c71c1099a6ba67d", null ],
    [ "update_params", "structaiopti.html#a833b900d14688a649c1037466adf444b", null ],
    [ "zero_gradients", "structaiopti.html#ae145c9527c45c9c98fe7a0b317245e66", null ]
];