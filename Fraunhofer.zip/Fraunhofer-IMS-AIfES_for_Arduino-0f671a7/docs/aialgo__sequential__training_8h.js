var aialgo__sequential__training_8h =
[
    [ "aialgo_backward_model", "aialgo__sequential__training_8h.html#aca4ec290b2db30cc76ad78aff649a69d", null ],
    [ "aialgo_calc_loss_model_f32", "aialgo__sequential__training_8h.html#adf0d71421bd6cab071633f275eb9b1b3", null ],
    [ "aialgo_calc_loss_model_q31", "aialgo__sequential__training_8h.html#a10e79c34f409b115573706895c63823d", null ],
    [ "aialgo_init_model_for_training", "aialgo__sequential__training_8h.html#a62a55277765b0bdd5c88955eb92e4c13", null ],
    [ "aialgo_print_loss_specs", "aialgo__sequential__training_8h.html#ab19a3d00e7ac130806780cc90e317a09", null ],
    [ "aialgo_print_optimizer_specs", "aialgo__sequential__training_8h.html#aa0a7ab4189d2f68c675d42aa687758e6", null ],
    [ "aialgo_schedule_training_memory", "aialgo__sequential__training_8h.html#aa6ae098c2add3651d216724f102e931b", null ],
    [ "aialgo_sizeof_training_memory", "aialgo__sequential__training_8h.html#aaa72bf9da57a600c0d4fef4ba03f725e", null ],
    [ "aialgo_train_model", "aialgo__sequential__training_8h.html#a0aadb77012a013367fb29f117ee5144c", null ],
    [ "aialgo_update_params_model", "aialgo__sequential__training_8h.html#a4650ca244c2d5086eb80190d2416f86e", null ],
    [ "aialgo_zero_gradients_model", "aialgo__sequential__training_8h.html#a20ba9e0bdcfd4e36bc1168789de7e99f", null ]
];