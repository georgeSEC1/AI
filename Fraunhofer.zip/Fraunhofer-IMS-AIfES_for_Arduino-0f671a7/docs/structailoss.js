var structailoss =
[
    [ "calc_delta", "structailoss.html#ae84860a963e24221ba373a1554f20930", null ],
    [ "calc_loss", "structailoss.html#afb6e75cd4aa201c51f7f220dc15abcb3", null ],
    [ "connection_layer", "structailoss.html#ad7053c8e36973515431688c9efe026ce", null ],
    [ "loss_configuration", "structailoss.html#a3121ea3e968d07206c419b358a5cfafc", null ],
    [ "loss_type", "structailoss.html#abf49a46edc25393b8cf2d799861961ea", null ]
];