var aifes__core_8h =
[
    [ "aicore_layertype", "structaicore__layertype.html", "structaicore__layertype" ],
    [ "aicore_losstype", "structaicore__losstype.html", "structaicore__losstype" ],
    [ "aicore_optitype", "structaicore__optitype.html", "structaicore__optitype" ],
    [ "aimodel", "structaimodel.html", "structaimodel" ],
    [ "ailayer", "structailayer.html", "structailayer" ],
    [ "ailoss", "structailoss.html", "structailoss" ],
    [ "aiopti", "structaiopti.html", "structaiopti" ],
    [ "aicore_layertype_t", "aifes__core_8h.html#aa24c6af16fb361ddbf2a07663e1e72be", null ],
    [ "aicore_losstype_t", "aifes__core_8h.html#a4ffd3907240bc205343116c20df08d70", null ],
    [ "aicore_optitype_t", "aifes__core_8h.html#a4d5c5bac82e4bea358807df79785e8c7", null ],
    [ "ailayer_t", "aifes__core_8h.html#a39d7709592d8923ba7b7955cc9986a26", null ],
    [ "ailoss_t", "aifes__core_8h.html#ac0d4550e74aa3c218857c73da31c251b", null ],
    [ "aimodel_t", "aifes__core_8h.html#a680bdf7bc140aa596e9dbe9f65e8e775", null ],
    [ "aiopti_t", "aifes__core_8h.html#a653bf4f9e571a738a1c7725e3d238a4c", null ]
];