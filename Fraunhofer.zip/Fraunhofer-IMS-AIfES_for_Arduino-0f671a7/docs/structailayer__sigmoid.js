var structailayer__sigmoid =
[
    [ "base", "structailayer__sigmoid.html#ab13782a46e3804246bf82a92955096b3", null ],
    [ "d_sigmoid", "structailayer__sigmoid.html#a881096205316190ae52edbc7c4997e4d", null ],
    [ "dtype", "structailayer__sigmoid.html#abf7a461af7296a09d5246ca13591b988", null ],
    [ "multiply", "structailayer__sigmoid.html#a50f5e44b0fca9c1e79a5287adb4a59eb", null ],
    [ "sigmoid", "structailayer__sigmoid.html#a427b044bddf241f9ffdf0258c7304c3c", null ]
];