var structaimath__q7__params =
[
    [ "shift", "structaimath__q7__params.html#a8f20d77488fe485aaf9ea8e9c5d7d35e", null ],
    [ "zero_point", "structaimath__q7__params.html#a6a54cbe2eb02707d6e9ae6f12d539e1b", null ]
];