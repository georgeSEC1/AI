var structailayer__elu__f32 =
[
    [ "alpha", "structailayer__elu__f32.html#a6986b52a6fd9d6c9388cb28a3583a306", null ],
    [ "base", "structailayer__elu__f32.html#a6d80585658fb6a5a14c46fefd49ac0ba", null ]
];