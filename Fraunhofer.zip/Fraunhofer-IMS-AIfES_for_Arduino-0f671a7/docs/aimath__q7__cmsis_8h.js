var aimath__q7__cmsis_8h =
[
    [ "aimath_q7_cmsis_linear32_bt", "aimath__q7__cmsis_8h.html#a046b3b2f59da4e06cf2be75aed10f342", null ]
];