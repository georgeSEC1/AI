var structailayer__elu =
[
    [ "alpha", "structailayer__elu.html#a6f10973551c9c29b8702e1d337ef9482", null ],
    [ "base", "structailayer__elu.html#ab13782a46e3804246bf82a92955096b3", null ],
    [ "d_elu", "structailayer__elu.html#a2817605e9ff5b047ff6192a2c8fae65d", null ],
    [ "dtype", "structailayer__elu.html#abf7a461af7296a09d5246ca13591b988", null ],
    [ "elu", "structailayer__elu.html#ac90eb9bb2a3de5697156ec356e4d7e0c", null ],
    [ "multiply", "structailayer__elu.html#a50f5e44b0fca9c1e79a5287adb4a59eb", null ]
];