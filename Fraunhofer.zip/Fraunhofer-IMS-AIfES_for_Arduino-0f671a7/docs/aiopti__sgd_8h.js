var aiopti__sgd_8h =
[
    [ "aiopti_sgd", "structaiopti__sgd.html", "structaiopti__sgd" ],
    [ "aiopti_sgd_t", "aiopti__sgd_8h.html#a61b25438699bd6f918253a70b0e92973", null ],
    [ "aiopti_sgd", "aiopti__sgd_8h.html#a17f3c6d6bc38f5be3d796a787aa4337d", null ],
    [ "aiopti_sgd_init_optimem_with_momentum", "aiopti__sgd_8h.html#a3ddbd762bf3c1fa7b4bf1af180bf2365", null ],
    [ "aiopti_sgd_init_optimem_without_momentum", "aiopti__sgd_8h.html#ac888d4220489192230ae82b3eb928d1a", null ],
    [ "aiopti_sgd_print_specs", "aiopti__sgd_8h.html#a935e38eb3fc504e1c63406b48ad404cd", null ],
    [ "aiopti_sgd_sizeof_optimem_with_momentum", "aiopti__sgd_8h.html#a7f6246c245c9ec247a565d3f42f0b9f4", null ],
    [ "aiopti_sgd_sizeof_optimem_without_momentum", "aiopti__sgd_8h.html#a5b9de582e0c2d7fd3ebc91515e492baa", null ],
    [ "aiopti_sgd_update_params_with_momentum", "aiopti__sgd_8h.html#abea711d9cf9403b45a216c06f9360009", null ],
    [ "aiopti_sgd_update_params_without_momentum", "aiopti__sgd_8h.html#aee9b5291db920666251e7556894b79f7", null ],
    [ "aiopti_sgd_zero_gradients", "aiopti__sgd_8h.html#a95ada79ffc34e8ef6567ee3b38a5f8df", null ],
    [ "aiopti_sgd_type", "aiopti__sgd_8h.html#aaf53c8e74f356f5f48976f95ba8fbab1", null ]
];