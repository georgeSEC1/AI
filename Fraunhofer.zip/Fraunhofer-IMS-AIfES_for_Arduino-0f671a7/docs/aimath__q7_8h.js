var aimath__q7_8h =
[
    [ "aimath_q7_params", "structaimath__q7__params.html", "structaimath__q7__params" ],
    [ "aiscalar_q7", "structaiscalar__q7.html", "structaiscalar__q7" ],
    [ "aimath_q7_params_t", "aimath__q7_8h.html#a79fdb2015c0ee007bda4a284e8df71b1", null ],
    [ "aiscalar_q7_t", "aimath__q7_8h.html#a3375a6a6444d822071023e6f930c4079", null ],
    [ "aimath_q7_calc_q_params_from_f32", "aimath__q7_8h.html#a8fba8e004fef67ff8ac8689002bdfaaa", null ],
    [ "aimath_q7_print_aiscalar", "aimath__q7_8h.html#a6211e4416168be5a9f3839a43b6345f8", null ],
    [ "aimath_q7_print_aitensor", "aimath__q7_8h.html#ab926f14179fe238d75e7987174a7a7b5", null ],
    [ "aimath_q7_quantize_tensor_from_f32", "aimath__q7_8h.html#a1a7229c2ed55114c37a0e30d74346b1a", null ],
    [ "aiq7", "aimath__q7_8h.html#a41e69a98d91e98757ac05f122fd8326f", null ]
];