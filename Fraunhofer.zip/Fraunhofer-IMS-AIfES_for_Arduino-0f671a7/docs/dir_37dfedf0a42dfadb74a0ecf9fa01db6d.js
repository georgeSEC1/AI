var dir_37dfedf0a42dfadb74a0ecf9fa01db6d =
[
    [ "aiopti_adam_default.h", "aiopti__adam__default_8h.html", "aiopti__adam__default_8h" ],
    [ "aiopti_sgd_default.h", "aiopti__sgd__default_8h.html", "aiopti__sgd__default_8h" ]
];