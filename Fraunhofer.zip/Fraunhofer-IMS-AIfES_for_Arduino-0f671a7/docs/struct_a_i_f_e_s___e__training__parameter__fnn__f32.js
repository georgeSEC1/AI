var struct_a_i_f_e_s___e__training__parameter__fnn__f32 =
[
    [ "batch_size", "struct_a_i_f_e_s___e__training__parameter__fnn__f32.html#a42b47542862c6c711ffbae806f59f730", null ],
    [ "early_stopping", "struct_a_i_f_e_s___e__training__parameter__fnn__f32.html#a08c80aea59827f5457bc262a85494a57", null ],
    [ "early_stopping_target_loss", "struct_a_i_f_e_s___e__training__parameter__fnn__f32.html#a7e0b5a1386fd3f0214d5f7910def14ef", null ],
    [ "epochs", "struct_a_i_f_e_s___e__training__parameter__fnn__f32.html#afcd5a1f03534b477aed17a33deb227ff", null ],
    [ "epochs_loss_print_interval", "struct_a_i_f_e_s___e__training__parameter__fnn__f32.html#ad7ad39d347c8d89d3744dbc2e765bfdf", null ],
    [ "learn_rate", "struct_a_i_f_e_s___e__training__parameter__fnn__f32.html#a057f27f74563c8ba830131c483b39902", null ],
    [ "loss", "struct_a_i_f_e_s___e__training__parameter__fnn__f32.html#afc50e0264bae1a9eed729878ec54d6e4", null ],
    [ "loss_print_function", "struct_a_i_f_e_s___e__training__parameter__fnn__f32.html#a395b877f575f44fcef603db0362368fc", null ],
    [ "optimizer", "struct_a_i_f_e_s___e__training__parameter__fnn__f32.html#a9f597ad8d0c7bedb69b05275c9c5acc3", null ],
    [ "sgd_momentum", "struct_a_i_f_e_s___e__training__parameter__fnn__f32.html#a349b9731a66bc2f669c93112b5fc50ff", null ]
];