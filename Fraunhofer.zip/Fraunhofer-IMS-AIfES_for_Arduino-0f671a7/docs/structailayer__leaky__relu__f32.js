var structailayer__leaky__relu__f32 =
[
    [ "alpha", "structailayer__leaky__relu__f32.html#a6986b52a6fd9d6c9388cb28a3583a306", null ],
    [ "base", "structailayer__leaky__relu__f32.html#a9a2a16f59298403e82b95dd4f9ab9865", null ]
];