var dir_a6118b80a1160589fd2e088758244a4b =
[
    [ "aiopti_adam.h", "aiopti__adam_8h.html", "aiopti__adam_8h" ],
    [ "aiopti_sgd.h", "aiopti__sgd_8h.html", "aiopti__sgd_8h" ]
];