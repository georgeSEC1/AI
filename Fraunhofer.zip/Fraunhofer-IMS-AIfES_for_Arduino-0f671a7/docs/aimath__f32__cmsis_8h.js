var aimath__f32__cmsis_8h =
[
    [ "aimath_f32_cmsis_linear", "aimath__f32__cmsis_8h.html#a38af60477fad26350bbb970a51966bf1", null ],
    [ "aimath_f32_cmsis_mat_mul", "aimath__f32__cmsis_8h.html#a14e97c2b77f067708008323e9a04aecf", null ]
];