var structailayer__softmax =
[
    [ "base", "structailayer__softmax.html#ab13782a46e3804246bf82a92955096b3", null ],
    [ "dtype", "structailayer__softmax.html#abf7a461af7296a09d5246ca13591b988", null ],
    [ "softmax", "structailayer__softmax.html#a25a735df26bb4003f7b15dfe4c95476f", null ]
];