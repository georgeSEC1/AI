var aiopti__adam_8h =
[
    [ "aiopti_adam", "structaiopti__adam.html", "structaiopti__adam" ],
    [ "aiopti_adam_momentums", "structaiopti__adam__momentums.html", "structaiopti__adam__momentums" ],
    [ "aiopti_adam_momentums_t", "aiopti__adam_8h.html#a40c00ead1bde1b1ac8c46282b0de8804", null ],
    [ "aiopti_adam_t", "aiopti__adam_8h.html#af6a2a8ada598e63f1be2ec6ff233c24f", null ],
    [ "aiopti_adam", "aiopti__adam_8h.html#af629e0de34a263c34060368bb8e7d6d0", null ],
    [ "aiopti_adam_init_optimem", "aiopti__adam_8h.html#a5fa06ea548cdaa249a98f5e9aaf0fc53", null ],
    [ "aiopti_adam_print_specs", "aiopti__adam_8h.html#a916f8f38aaeba5814db961c3ff00a3d4", null ],
    [ "aiopti_adam_sizeof_optimem", "aiopti__adam_8h.html#a79d431f3d4b7d1d0a78d720f297abc30", null ],
    [ "aiopti_adam_update_params", "aiopti__adam_8h.html#a4b9e08fa3872a6edcf3dbfb81c53f641", null ],
    [ "aiopti_adam_zero_gradients", "aiopti__adam_8h.html#a735b282e282209a39b101cd8f04cf43d", null ],
    [ "aiopti_adam_type", "aiopti__adam_8h.html#af4b770ca8b7c46a865a01dedd0c866af", null ]
];